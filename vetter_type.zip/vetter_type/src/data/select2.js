const select_list2 = [
    {
       opt1:'연자명',
       opt2:'장재원',
       opt3:'이혜원'
    },
]
export default select_list2;