const list_vod = [
    {
        link:"#",
        img: "/images/thum_w277.jpg",
        alt: "임상강좌 이미지",
        title:"2021 석천나눔재간 헬스케어 연구지원 및 연구실정발표 연구지원 및 연구실정발표 연구실정발표",
        presenter:"장재원 교수(서울대 수의과대학)",
        labels: ["피부", "AD"],
        point:"강아지 잇몸 색상에 따라 파악할 수 있는 질환"
    },
    {
        link:"#",
        img: "/images/thum_w277.jpg",
        alt: "임상강좌 이미지",
        title:"2023 석천나눔재간 헬스케어 연구지원 및 연구실정발표 연구지원 및 연구실정발표 연구실정발표",
        presenter:"이혜원 교수(서울대 수의과대학)",
        labels: ["피부", "New"],
        point:"강아지 잇몸 색상에 따라 파악할 수 있는 질환, 강아지 잇몸 색상에 따라 파악할 수 있는 질환, 강아지 잇몸 색상에 따라 파악할 수 있는 질환"
    },
    {
        link:"#",
        img: "/images/thum_w277.jpg",
        alt: "임상강좌 이미지",
        title:"2023 석천나눔재간 헬스케어 연구지원 및 연구실정발표 연구지원 및 연구실정발표 연구실정발표",
        presenter:"이혜원 교수(서울대 수의과대학)",
        labels: ["질환", "Live"],
    },
    {
        link:"#",
        img: "/images/thum_w277.jpg",
        alt: "임상강좌 이미지",
        title:"2023 석천나눔재간 헬스케어 연구지원 및 연구실정발표 연구지원 및 연구실정발표 연구실정발표",
        presenter:"이혜원 교수(서울대 수의과대학)",
        labels: ["질환", "Live"],
    },
    {
        link:"#",
        img: "/images/thum_w277.jpg",
        alt: "임상강좌 이미지",
        title:"2023 석천나눔재간 헬스케어 연구지원 및 연구실정발표 연구지원 및 연구실정발표 연구실정발표",
        presenter:"이혜원 교수(서울대 수의과대학)",
        labels: ["피부"],
    },
]
export default list_vod;