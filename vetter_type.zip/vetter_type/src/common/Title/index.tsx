import {TitleContainer } from "common/common.style";

interface Props {
    readonly label:string;
}
export const Title = ({label}: Props) => {
    return (
        <TitleContainer>
            {label}
        </TitleContainer>
    );
};  

