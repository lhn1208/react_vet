interface Props {
    readonly selectList?: ReadonlyArray<{ 
        label: string;
        value: string;
    }>;
}
export default function SelectBox({selectList}:Props) {
    return(
        <select>
            {selectList && selectList.map((option, index)  => (
                <option key={index} value={option.value}>
                    {option.label}
                </option>
            ))}
    
        </select>
    )

}