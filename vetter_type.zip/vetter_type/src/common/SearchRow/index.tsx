import {SchGroup } from "list/list.style"
import DateInput from "./DateInput"
import SelectBox from "./SelectBox"
import SchInput from "./SchInput";

export const SearchRow = () => {
    const select_list1 = [
        { label: '질환군', value: 'disease' },
        { label: '피부', value: 'skin' },
        { label: '호흡기질환', value: 'respiratory' }
    ];
    const select_list2 = [
        { label: '연자명', value: 'actor1' },
        { label: '장재원', value: 'actor2' },
        { label: '이혜원', value: 'actress' }
    ];
    return (
        <SchGroup>
            <li>
                <DateInput />
            </li>
            <li>
                <SelectBox selectList={select_list1} />
            </li>
            <li>
                <SelectBox selectList={select_list2} />
            </li>
            <li>
                <SchInput />
            </li>
        </SchGroup>
    )
}