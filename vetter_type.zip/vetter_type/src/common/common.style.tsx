import styled from '@emotion/styled';
// import { Global, css } from '@emotion/react';
import { customStyles } from 'common/custom.style';
const { size, weight } = customStyles.font;
const {colors, contWidth,PosCenterY,Transition,MouseOver,icoCollect,flexOpt}  = customStyles;

interface ContainerProps {
    readonly primary?: boolean;
}   
  
interface PdProps {
    readonly pdType0?: boolean;
}   
  
export const ContainerWrap = styled.div<ContainerProps & PdProps>`
    .h2_title{margin-bottom:24px;}
    padding:${props => (props.pdType0 ? '70px': "100px")} 0 30px;
    background-color: ${props => (props.primary ? '#f5f5fa' : '#fff')};
    h2,h3,h4{ ${weight.bold}}
   
`
export const Container=styled.div<PdProps>`
    display:flex;
    position:relative;
    justify-content:space-between; 
    padding-top: ${props => (props.pdType0 ? '0': "60px")};
    ${contWidth}
    padding-bottom:40px;
    .inner_box{
        position:relative;
        flex-basis:865px;
        max-width:865px;
    }
`
export const AdBanner = styled.a`
    ${contWidth}
    margin-top:30px;
    display:block;
    
`
export const SectionList=styled.section`
    &+section{
        margin-top:40px;
    }
`
export const TitleContainer=styled.h2`
    margin:20px 0;
    ${size.ft22}
    i{
        margin-left:10px;
    }
`

export const FlexBothEnds=styled.div`
    ${flexOpt.scbAlignCenter};
`
export const CheckBox=styled.span`
display:inline-block;
input[type="checkbox"]{
    display:none;
    &+span{
        position:relative;
        display:inline-block;
        width:20px;
        height:20px;
        margin-right:6px;
        border:1px solid ${colors.greyE1};
        vertical-align:middle;
        ${size.ft14};
    }
}
input[type="checkbox"]:checked{
    &+span:before{
        content:"";
        position:absolute;
        top:14%;
        left:50%;
        width:8px;
        height:14px;
        transform:rotate(45deg) translateX(-50%);
        border-bottom:1px solid ${colors.blue};
        border-right:1px solid ${colors.blue};
       
    }
}   
`
export const FullContent = styled.div`
    padding:60px 0 40px;
    ${contWidth};
`
/* Header footer layout*/
export const HeaderStyle = styled.header`
    position:fixed;
    top:0; 
    left:0;
    right:0;
    bottom:0;
    height:70px;
    z-index:100;
    background-color:#fff;
    box-sizing: border-box;
    border-bottom: 1px solid #ccc;
    .header_inner{
       
        height:70px;
        >div{
        }
    }
    
`
export const SkipNav = styled.div`
    position:relative;
    z-index:9999;
    a{
        position: absolute; 
        top: -200px; 
        left:0; 
        width: 100%; 
        line-height: 30px; 
        color:#fff; 
        background-color: #00befc;
        text-align: center; 
        ${size.ft16}
    }
    a:focus, a:active{top: 0;}
}
`
export const Inner  = styled.div`
    display:flex;
    justify-content:space-between;
    align-items:center;
    height:100%;
    position:relative;
    ${contWidth}
    h1{
        
        left:0;
        ${PosCenterY};
    }
    &>menu>ul{
        display:flex;
        margin-left:230px;
        >li{
            position:relative;
            >a{
                display:block;
                width:100%;
                padding:25px 0;
                ${size.ft18};
                ${weight.bold};
                &.on{
                    color:${colors.blue};
                    
                }   
            }
            
            &+li{
                margin-left:30px;
            }
            &:hover{
                ul{
                    display:block;
                }
            }
        }
    }
    .right{
        display:flex;
        align-items:center;
        gap:20px;
        .identify{
            ${size.ft14};
        }
    }
`
interface MemberProps {
    readonly member?: string;
}   
export const Submenu  = styled.ul<MemberProps>`
    display:none;
    position:absolute;
    top:${props => (props.member ? '69px' : '68px')};;
    left:${props => (props.member ? '-62px' : '-16px')};
    min-width:127px;
    padding:16px;
    border:1px solid ${colors.greyBb};
    ${Transition.sec2}
    z-index:90;
    background:${colors.white};
    box-sizing:border-box;
    li{
        line-height:1.8;
    }
    a{
      display:block;
      ${size.ft14}  
      ${weight.normal}
      ${MouseOver.color}
      text-align:left;
    }
    &.on{
        opacity:1;
        visibility:visible;
    }
`

export const Member=styled.button`
    display:inline-block;
    position:relative;
    width:28px;
    height:70px;
    &:before{
        content:"";
        display:block;
        width:28px;
        height:24px;
        ${icoCollect};
        background-position:0 0;
    }
   
    i{
        position:absolute;
        width:7px;
        height:7px;
        top:18px;
        right:0;
        background:${colors.lightYg};
        border-radius:50%;
        text-indent:-9999em;
    }
    
    &:hover ul{
        display:block;
    }
    
`
export const Search=styled.div`
    border:2px solid rgb(0, 190, 252);
    width:260px;
    height:40px;
    padding:0 40px 0 10px;
    box-sizing: border-box;
    position:relative;
    input[type="search"]{
        width:100%;
        line-height:34px;
    }
    .btn_sch{
        ${PosCenterY};
        width:40px;
        height:100%;
        ${icoCollect};
        background-position:-24px 7px;
    }
`
export const Gnb=styled.button`
    position:relative;
    width:24px;
    height:14px;
    &:before,&:after{
        content:"";
    }
    &:before,&:after,.ico_menu{
        position:absolute;
        left:0;
        height:2px;
        background:#000;
        ${Transition.default}
    }
    &:before{
        top:0;
        width:100%;
    }
    .ico_menu{
        text-indent:-9999em;
        top:6px;
        width:18px;
    }
    &:after{
        top:12px;
        width:12px;
    }

    &.on{
        .ico_menu{
            display:none;
        }
        &:before{
            transform:translateY(7px) rotate(45deg);
        }
        &:after{
            width:24px;
            transform:translateY(-5px) rotate(-45deg);
        }
    }
`
export const AllMenu = styled.menu`
    display:none;
    position:absolute;
    top:70px;
    left:0;
    right:0;
    width:100%;
    padding:80px 0;
    background-color:${colors.white};
    border-bottom:1px solid ${colors.geryC};
    z-index:92;
    .inner{
       display:flex;
       ${contWidth};
    }

    h2{
        ${size.ft24}
        ${weight.semiBold};
        margin-bottom:20px;
    }
    .col{
        width:24%;
        padding:0 10px;
        box-sizing:border-box;
        li{
            line-height:2.2;
            a{
                ${MouseOver.color};
                ${weight.normal};
                ${size.ft16};
            }
        }
    }
    &.on{
        display:block;
    }
    
`
/*footer */
export const FooterLayout=styled.div`
    border-top:1px solid ${colors.greyE1};
    .footer{
        padding:40px 0px;
        ${contWidth};
        .footer_inner{
            ${flexOpt.scb}
            align-items:flex-start;
        }
    }
    .vet_info{
        ${size.ft14};      
        ${weight.normal};   
    }
    .site_link{
        margin-top:14px;
        margin-bottom:10px;
        a{
            &:first-of-type{
                padding-left:0;
            }
            display:inline-block;
            position:relative;
            padding:0 6px;
            ${size.ft14};      
            ${weight.normal};   
            color:#5d5d5d;
            &+a:before{
                content:"";
                position:absolute;
                ${PosCenterY}
                left:0;
                width:1px;
                height:10px;
                background-color:${colors.greyE1};
            }
        }
    }
    address{
        color:#939393;
        &>span{
            margin-right:16px;
        }
    }
    .copy{
        margin-top:20px;
        ${size.ft13};     
        color:#939393;
    }
    
`
export const FamliySite=styled.div`
    position: relative;
    width:228px;
    button.site_box{
        position:relative;
        width:100%;
        line-height:33px;
        padding:0 14px;
        background-color:${colors.greyF2};
        text-align:left;
        ${size.ft14}
        box-sizing:border-box;
        &:after{
            content:"";
            ${PosCenterY}
            right:12px;;
            width:12px;
            height:12px;
            ${icoCollect}
            background-position: -200px -4px;
        }
    }
    .sites{
        display:none;
        position:absolute;
        bottom:33px; 
        left:0;
        width:100%;
        border:1px solid ${colors.greyE1};
        background-color: ${colors.white};
        padding:10px 0;
        box-sizing:border-box;
        a{
            display: block;
            padding:6px 10px;
            color:${colors.black1f}
            ${MouseOver.default}
        }
        &.open{
            display:block;
        }
    }
`
export const NotFound = styled.div`
  text-align:center;
`;