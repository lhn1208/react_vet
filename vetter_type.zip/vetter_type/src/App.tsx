import { Main } from 'Main';
import { ClassLive } from 'class/ClassLive';
import { ClassMain } from 'class/ClassMain';
import ClassVod from 'class/ClassVod';
import { Footer } from 'common/Footer';
import { Header } from 'common/Header';
import DignosCase from 'community/DignosCase';
import Event from 'community/Event';
import FreeBoard from 'community/FreeBoard';
import News from 'library/News';
import Research from 'library/Reasearch';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { NotFound } from "common/common.style";
function App() {
  

  return (
   <>
     <BrowserRouter>
     <Header />
      <Routes>  
        <Route path='/' element={<Main />} />
        <Route path='/class' element={<ClassMain />} />
        <Route path='/class/live' element={<ClassLive />} />
        <Route path='/class/vod' element={<ClassVod/>} />
        <Route path='/library' element={<News />} />
        <Route path='/library/reportsch' element={<Research />} />
        <Route path='/community' element={<FreeBoard />} />
        <Route path='/community/dignos_case' element={<DignosCase />} />
        <Route path='/community/event' element={<Event />} />
        <Route path='*' element={<NotFound>404<br /> Not Found</NotFound>} />
      </Routes>
      <Footer/>
     </BrowserRouter>
   </>
  );
}

export default App;
