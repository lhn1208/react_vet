
import listLive from 'data/list_live';
import { DataNone, IcoSch, Label, ListType } from './list.style';
interface Props {
    readonly listVod?: ReadonlyArray<{ 
        link: string;
        img: string;
        alt: string;
        title: string;
        presenter: string;
        labels: string[];
        point?: string;
    }>;
    readonly type:string;
}

export const ListAlbum = ({listVod = [],type}: Props) => {
    return (
        <>
        
            {type === "vod" && listVod.length > 0 && (
                 <ListType col="col3">     
                 
                    {listVod.map((item, index) => (
                        <li key={index}>
                            <a href={item.link}>
                                <figure>
                                    <img src={item.img} alt={item.alt} />
                                </figure>
                                <figcaption>
                                    {item.labels.map((label, labelIndex) => (
                                        <Label
                                            key={labelIndex}
                                            $mode={label === "AD" || label === "New" ? "gradient" : label === "Live" ? "orange" : undefined}
                                            className={label === "AD" || label === "New" || label === "Live" ? "en" : undefined}
                                        >
                                            {label}
                                        </Label>
                                    ))}
                                    <strong className="title">{item.title} </strong>
                                    <p className="presenter">{item.presenter}</p>
                                </figcaption>
                            </a>
                        </li>
                        
                    ))}
                 </ListType>
             )}
            {type === "list" && listLive.length > 0 && (
                <ListType col="col1">
                    {listVod.map((item, index) => (
                        <li key={index}>
                            <a href={item.link}>
                                <figure>
                                    <img src={item.img} alt={item.alt} />
                                </figure>
                                <figcaption>
                                    {item.labels.map((label, labelIndex) => (
                                        <Label
                                            key={labelIndex}
                                            $mode={label === "AD" || label === "New" ? "gradient" : label === "Live" ? "orange" : undefined}
                                            className={label === "AD" || label === "New" || label === "Live" ? "en" : undefined}
                                        >
                                            {label}
                                        </Label>
                                    ))}
                                    <strong className="title">{item.title} </strong>
                                    <p className="presenter">{item.presenter}</p>
                                    <p className="point">{item.point}</p>
                                </figcaption>
                            </a>
                        </li>
                        
                    ))}
                </ListType>
            )}
            {type === "live" && listLive.length > 0 && (
                <ListType col="col3">
                    {listLive.map((item, index) => (
                    <li key={index}>
                        <a href={item.link}>
                            <figure>
                                <img src={item.img} alt={item.alt} />
                                <Label cate="cate">{item.cate}</Label>
                            </figure>
                            <figcaption>
                                <strong className="title">{item.title}</strong>
                                <p className="date">{item.date}</p>
                            </figcaption>
                        </a>
                    </li>
                    ))}
                </ListType>
            )}
            {!(type === "vod" && listVod.length > 0) && !(type === "live" && listLive.length > 0) && !(type === "list" && listVod.length > 0) && (
                <DataNone>
                    <IcoSch></IcoSch>데이터가 없습니다.
                </DataNone>
            )}     
        </>
    );
};  