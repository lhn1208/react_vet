import { Recomm } from "./Recomm";
interface ListSecProps {
    showCol: boolean;
}

export const ListRecomm= ({ showCol }:ListSecProps) => {
    return (
        <>
            {showCol ? (
                <Recomm type="album" />
            ):(
                <Recomm type="list" />
            )}
        </>
    );
};  