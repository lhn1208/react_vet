import { ListSet } from "./list.style";
interface Props{
    readonly showCol:boolean,
    readonly toggleShowCol?: () => void;
  }
export default function ListSelectSet({ showCol, toggleShowCol }: Props) {
    return (
        <ListSet>
            <button className={showCol ? 'album on' : 'album'} onClick={toggleShowCol}></button>
            <button className={!showCol ? 'list on' : 'list'} onClick={toggleShowCol}></button>
        </ListSet>
    )}
