import { Aside } from "aside/aside.style";
import { SectionList, Container, ContainerWrap } from "common/common.style";
import { TopBanner } from "common/TopBanner";
import { KeyWordPick } from "./KeyWordPick";
import { Title } from "common/Title";
import { ListRecomm } from "list/ListRecomm";
import { BtnMore } from "list/list.style";
import News from "aside/News";
import Services from "aside/Services";
import Banner from "aside/Banner";
import { ListAlbum } from "list/ListAlbum";
import listVod from 'data/list_vod';
import { useState } from "react";
import ListSelectSet from "list/ListSelectSet";
export const Main = () => {
  //showCol1 상태의 현재값(초기값) = true,
    //setShowCol1은 상태 값을 업데이트하는 함수
    const [showCol, setShowCol] = useState(true);
    const toggleShowCol = () => {
        setShowCol(!showCol);
    };
  return (
  <>
    <ContainerWrap primary={true} id="content">
      <TopBanner />
      <Container>
        <div className="inner_box">
          <KeyWordPick />
          <SectionList>
            <Title label="임상강좌 VOD" />
            <ListAlbum listVod={listVod} type="vod" />
          </SectionList>
          <SectionList>
            <Title label="LIVE 세미나" />
            <ListAlbum type="live" />
          </SectionList>
        </div>
        <Aside>
          <News />
          <Services />
          <div>
              <Banner type="banner1"/>
              <Banner type="banner2"/>
          </div>
        </Aside>
      </Container>
    </ContainerWrap>
    <ContainerWrap>
      <Container pdType0={true}>
        <div className="inner_box">
          <Title label="추천 콘텐츠" />
          <ListSelectSet showCol={showCol} toggleShowCol={toggleShowCol} />
          <ListRecomm showCol={showCol} />
          <BtnMore>더보기 1/5</BtnMore>
        </div>
        <Aside>
            <div>
                <Banner type="banner1"/>
                <Banner type="banner2"/>
            </div>             
        </Aside>
      </Container>
    </ContainerWrap>
  </>
  );
};  