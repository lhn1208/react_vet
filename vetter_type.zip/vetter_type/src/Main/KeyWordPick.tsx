import { Pick } from "./main.style";

export const KeyWordPick = () => {
    return (
        <Pick>
            <strong>Pick</strong>
            <a href="#none">#초음파아카데미</a>
            <a href="#none">#이벤트</a>
            <a href="#none">#이달의심사이슈</a>
            <a href="#none">#보험심사청구</a>
            <a href="#none">#컨설팅</a>
        </Pick>
    );
};  