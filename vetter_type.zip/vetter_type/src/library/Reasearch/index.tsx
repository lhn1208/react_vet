import { ListUl, VisualStyle } from "community/community.style";
import { ContainerWrap,FullContent } from "../../common/common.style";
import Visual from "../Visual";
import Form from "./Form";

export default function Research() {
    return(
        <ContainerWrap id="content" pdType0={true}>
            <VisualStyle type="report">
                <Visual title="논문검색" sub_title="국내외 다양한 논문검색 채널을 제공합니다."></Visual>
            </VisualStyle>
            <FullContent>
                <ListUl type="rsch">
                    <Form 
                        title="PubMed"
                        cont={
                            <>
                                미국 국립의학도서관(NLM)에서 제공하는<br />
                                최대 규모 서지 데이터베이스인<br />MEDLINE 검색 엔진
                            </>
                        }
                        logoclass="logo1"
                    />
                   <Form 
                        title="Google Scholar"
                        cont={
                            <>
                                전 세계 학술 연구 관련<br />데이터 제공
                            </>
                        }
                        logoclass="logo2"
                    />
                    <Form 
                        title="NDSL"
                        cont={
                            <>
                                과학기술정보의 전자도서관으로<br />지식발견형 검색서비스 제공
                            </>
                        }
                        logoclass="logo3"
                    />
                    <Form 
                        title="RISS"
                        cont={
                            <>
                                한국교육학술정보원에서 제공하는<br />학술연구정보화 시스템
                            </>
                        }
                        logoclass="logo4"
                    />
                    <Form 
                        title="Cochrane Library"
                        cont={
                            <>
                                연구 및 임상에서 활용가능한 데이터 제공
                            </>
                        }
                        logoclass="logo5"
                    />
                    <Form 
                        title="NEJM"
                        cont={
                            <>
                                세계 최고 권위의 저널 제공   
                            </>
                        }
                        logoclass="logo6"
                    />
                    <Form 
                        title="JAMA"
                        cont={
                            <>
                                미국의학협회에서 출판되는<br/>9종의 전문 임상 학술지 제공
                            </>
                        }
                        logoclass="logo7"
                    />
                   <Form 
                        title="THE LANCET"
                        cont={
                            <>
                                영국 최고 권위의 저널 제공
                            </>
                        }  
                        logoclass="logo8"
                    />
                </ListUl>
            </FullContent>
        </ContainerWrap>
    )
}