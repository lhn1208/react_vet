interface Props {
    readonly title:string,
    readonly cont: React.ReactNode;
    readonly logoclass?:string
    
}
export default function Form({title,cont,logoclass}: Props) {
    return(
        <li>
            <a href="#none">
                <i>바로가기 아이콘</i>
                <div className="info">
                    <h3 className="tit">{title}</h3>
                    <p>{cont}</p>
                </div>
                <div className="logo_area">
                    <span className={`journal ${logoclass || ''}`}></span>
                </div>
            </a>
        </li>
    )
}