import DateInput from "common/SearchRow/DateInput";
import SchInput from "common/SearchRow/SchInput";
import { Container, ContainerWrap } from "common/common.style";
import { BordWrapStyle, VisualStyle } from "community/community.style";
import Visual from "library/Visual";
import { BtnMore, SchGroup } from "list/list.style";
import NewsBoard from "./NewsBoard";
import { Aside } from "aside/aside.style";
import Banner from "aside/Banner";

export default function News() {
    return(
        <ContainerWrap id="content" pdType0={true}>     
           <VisualStyle type="news">
                <Visual title="베터빌 뉴스" sub_title="수의학계 각종 현안 및 관심사와 연관된 최신 뉴스를 제공합니다."></Visual>
            </VisualStyle>
            <Container>
                <div className="inner_box">
                    <BordWrapStyle type="news">
                        <SchGroup>
                            <li className="sel">
                                <DateInput />
                            </li>
                            <li className="sch">
                                <SchInput />
                            </li>
                        </SchGroup>  
                        <NewsBoard />
                        <BtnMore>더보기 1/5</BtnMore>
                    </BordWrapStyle>
                </div>
                <Aside>
                    <div>
                        <Banner type="banner1"/>
                    </div>    
                </Aside>
            </Container>
        </ContainerWrap>
           
    )

}