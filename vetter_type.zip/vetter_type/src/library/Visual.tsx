interface Props {
    readonly title:string,
    readonly sub_title:string;
}

export default function Visual({title,sub_title}: Props) {
    return(
        <div className="visual_inner">
            <h2>{title}</h2>
            <p>{sub_title}</p>
        </div>
           
    )

}