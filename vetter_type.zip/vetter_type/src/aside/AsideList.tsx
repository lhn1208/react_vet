
import { List } from "./aside.style";
import { Title } from "./Title";
interface Props{
   readonly classify?:string,
   readonly presenter?:string;
 }
export default function AsideList({classify , presenter}:Props){
 return (
    <>
         <Title label="추천 VOD" />
         <List href="#none">
            <span className="img"><img src={'/images/aside_img.jpg'} alt="이미지 설명" /></span>
            <div className="cont">
                {classify && <p className="classify">{classify}</p>}
                <strong className="title">Clinical Implication of Glycemic Variability Glycemic Variabilit</strong>
                {presenter && <p className="txt_small">{presenter}</p>}
            </div>
         </List>
    </>
 );
}