import { TitleContainer } from "aside/aside.style";

interface Props {
    readonly label:string;
}
export const Title = ({label}: Props) => {
    return (
        <TitleContainer>
            {label}
        </TitleContainer>
    );
};  

