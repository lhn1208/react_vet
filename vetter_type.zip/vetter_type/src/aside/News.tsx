import { Title } from "./Title";
import { NewsStyle } from "./aside.style";

export default function News() {
    return(
        <NewsStyle>
            <Title label="베터빌 뉴스" />
            <ul>
                <li><a href="#none">반려동물 줄기세포 치료 티트템 트템 웨비나 웨비나 웨비나 웨비나</a></li>
                <li><a href="#none">동물진료 표준화 연구 공청회 17일 개최</a></li>
                <li><a href="#none">고양이 염증 진단 항목 SAA</a></li>
            </ul>
        </NewsStyle>
           
    )

}