import { StarIco, HeartIco } from "./class.style";
interface Props{
    readonly type:string,
    readonly className?: string,
    readonly onClick?: () => void;
  }
export default function FavIco({ type, className, onClick }:Props) {
    return(
        <>
        {type === "star" && (
            /*props에 classname과 onclick 추가 */
            <StarIco
                className={className}
                onClick={onClick}
            >
            </StarIco>
        )}
        {type === "heart" && (
             <HeartIco
             className={className}
             onClick={onClick}
            >
            </HeartIco>
        )}
        </>
    )
}