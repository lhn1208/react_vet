import { Title } from "common/Title";
import { TopBanner } from "common/TopBanner";
import { Container, ContainerWrap, FlexBothEnds } from "common/common.style";
import { ClassState, IcoLabel, LiveGuideGrp, LiveSeminar, LiveTable } from "./class.style";
import list_program from '../data/list_porgram';
import { Aside } from "aside/aside.style";
import AsideList from "aside/AsideList";
import Banner from "aside/Banner";
export const ClassLive = () => {
    let prevDate: string | null = null; // 이전 날짜를 추적하는 변수를 초기화합니다.
    return (
        <ContainerWrap id="content">
            <TopBanner />
            <Container>
                <div className="inner_box">
                    <Title label="Live 세미나" />
                    <LiveSeminar>
                        <FlexBothEnds className="live_top">
                            <button className="btn">편성표 다운로드</button>
                            <LiveGuideGrp>
                                <span>전체</span>
                                <span>세미나<IcoLabel className="pink">S</IcoLabel></span>
                                <span>웹심포지움 <IcoLabel className="purple">W</IcoLabel></span>
                            </LiveGuideGrp>
                        </FlexBothEnds>
                        <LiveTable>
                            <table>
                                <caption>세미나 편성표 표</caption>
                                <colgroup>
                                    <col width="93px" />
                                    <col width="80px" />
                                    <col width="*" />
                                </colgroup>
                                <tbody>
                                {list_program.map((item, index) => {
                                    const isFirstRow = prevDate !== item.date; // Check if it's the first row with a new date
                                    if (isFirstRow) {
                                        prevDate = item.date; // Update the previous date
                                    }
                                    const dateMatch = item.date.match(/(\d{1,2}\/\d{1,2})(.*)/);
                                    if (!dateMatch) {
                                        // match 결과가 null이면 처리할 내용 추가
                                        return null;
                                    }
                                    const [date, week] = dateMatch.slice(1); // 날짜와 요일을 분리
                                    const timeMatch = item.time.match(/(\d{1,2}:\d{1,2})~(\d{1,2}:\d{1,2})/);
                                    if (!timeMatch) {return null;}
                                    const [startTime, endTime] = timeMatch.slice(1);    
                                    const states = item.state.split(',');
                                    const [applyYN]= Array.from(item.apply);
                                    return (
                                        <tr key={index}>
                                            {isFirstRow && (
                                            <th rowSpan={list_program.filter(p => p.date === item.date).length} scope="col">
                                                <strong>{date}</strong>
                                                <span className="week">{week}</span>
                                            </th>
                                            )}
                                            <td className={`time ${isFirstRow ? 'purple' : 'green'}`}>
                                                <strong>{startTime}</strong>
                                                ~{endTime}
                                            </td>
                                            <td>
                                                <a href="#none">
                                                    <span className="cate_class">{item.cate}</span>
                                                    <div className="pro_title">
                                                        <IcoLabel className="pink">S</IcoLabel>
                                                        {item.title}
                                                    </div>
                                                    <span className="presenter">{item.presenter}</span>
                                                    {states.length > 0 && ( // states 배열이 비어있지 않은지 확인
                                                    <ClassState>
                                                        {states.map((state, stateIndex) => (
                                                        // 빈 값이 아닌 경우에만 <span> 요소를 렌더링
                                                        state && <span key={stateIndex}>{state}</span>
                                                        ))}
                                                    </ClassState>
                                                    )}
                                                    <div className="apply">
                                                        {applyYN === 'Y' ? (
                                                            <div className="state possible">신청가능</div>
                                                        ) : (
                                                            <div className="state">신청완료</div>
                                                        )}
                                                        <div className="people">{item.people}명<span>/{item.total}명</span></div>
                                                    </div>
                                                </a>
                                            </td>
                                        </tr>
                                    );
                                })}
                                </tbody>
                            </table>
                        </LiveTable>
                    </LiveSeminar>
                </div>
                <Aside>
                    <div>
                        <AsideList presenter="이정은 교수 (ㅇㅇㅇ병원 00내과)"/>
                    </div>
                    <div>
                        <Banner type="banner1"/>
                    </div>    
                </Aside>
            </Container>
        </ContainerWrap>
    );
};  