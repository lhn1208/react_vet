import AsideList from "aside/AsideList";
import Banner from "aside/Banner";
import { Aside } from "aside/aside.style";
import { SearchRow } from "common/SearchRow";
import { Title } from "common/Title";
import { TopBanner } from "common/TopBanner";
import { Container, ContainerWrap, SectionList } from "common/common.style";
import listClass from 'data/list_class';
import { ListAlbum } from "list/ListAlbum";
import ListSelectSet from "list/ListSelectSet";
import { BtnMore, ListOptStyle } from "list/list.style";
import { useState } from "react";

export const ClassMain = () => {
    const [showCol, setShowCol] = useState(true);
    const toggleShowCol = () => {
        setShowCol(!showCol);
    };
    return (
        <ContainerWrap id="content">
            <TopBanner />
            <Container>
                <div className="inner_box">
                    <SectionList>
                        <Title label="임상강좌 VOD" />
                        <SearchRow />
                        <ListOptStyle>
                            <strong>전체(3)</strong>
                             <div className="right">
                                <ListSelectSet showCol={showCol} toggleShowCol={toggleShowCol} />
                            </div>
                        </ListOptStyle>
                        {showCol ? (
                            <ListAlbum listVod={listClass} type="vod" />
                        ):(
                            <ListAlbum listVod={listClass} type="list" />
                        )}
                        <BtnMore>더보기 1/5</BtnMore>
                    </SectionList>
                </div>
                <Aside>
                    <div>
                        <AsideList presenter="이정은 교수 (ㅇㅇㅇ병원 00내과)"/>
                    </div>
                    <div>
                        <Banner type="banner1"/>
                    </div>    
                </Aside>
            </Container>
        </ContainerWrap>
    );
};  