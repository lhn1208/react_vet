import styled from '@emotion/styled'
import { css } from '@emotion/react';
import { customStyles } from '../common/custom.style';
import { MouseOver, PosCenterY, flexOpt } from '../styles/variables';

const { size, weight } = customStyles.font;
const {rdSize} = customStyles.LabelStyle;
const {colors ,contWidth,ellipsis,icoStyle,icoCollect,bgCollect}  = customStyles;
interface VisualProps {
    readonly type?: string,
}   
  
export const VisualStyle = styled.div<VisualProps>`
    height:294px;
    padding-top:130px;
    box-sizing: border-box;
    color:${colors.white};
    ${({ type }) => {
        if (type === "news") {
            return bgCollect.news;
        } else if (type === "report") {
            return bgCollect.report;
        } else if (type === "tip") {
            return bgCollect.tip;
        } else if (type === "case") {
            return bgCollect.case;
        } else if (type === "freeboard") {
            return bgCollect.freeBoard;
        } else {
            // Fallback or default styling if none of the conditions match
            //  return bgCollect.default;
        }
    }}

    .visual_inner{
        ${contWidth}
        h2{
            margin-bottom:16px;
            padding-bottom:25px;
            border-bottom:1px solid ${colors.white};
            ${size.ft30}
            ${weight.bold}
        }
        p{
            ${size.ft16}
        }
    }
   
`
export const BordWrapStyle = styled.div<VisualProps>`
    padding-top:40px;
    .sch_area{
        width:360px;
        margin-bottom:40px;
        &.bt_gray{
            border-bottom: 1px solid ${colors.greyE1};
        }
    }
    ${({ type }) => type==="freeboard" &&
        css`
        .sch{
          flex-grow:2;
          .sch_box{
            width:auto;
          }
        }
        
    `}
    ${({ type }) => type === "news" &&
        css`
            .sch {
                flex-grow: 2.4;
                .sch_box {
                    width: auto;
                }
            }
        `}
`;
export const TableBoard = styled.div`
table{
    width:100%;
    .align_left{text-align:left;}
    th{
        padding:14px;
        ${size.ft16}
        ${weight.bold}
        border-bottom: 1px solid #000;
    }
    td{
        line-height:46px;
        border-bottom:1px solid ${colors.geryC};
        text-align:center;
        ${size.ft14}
        color:${colors.grey6};
        &.title{
            max-width:340px;
            text-align:left;
            ${ellipsis.default}
            .comm_cnt{
                margin-left:6px;
                color:${colors.blue};
                ${weight.bold};
            }
            i{
                ${icoStyle}
                margin-left:6px;
                background-position: -140px -30px;
            }
        }
    }
}
`
export const BrnWrite = styled.div`
text-align:right;
    button{
        position: relative;
        min-width:130px;
        line-height:40px;
        border-radius:5px;
        padding-left:18px;
        background-color:${colors.blue};
        color:#fff;
        ${weight.bold};
        &:before{
            content:"";
            display:inline-block;
            width:16px;
            height:16px;
            ${PosCenterY};
            left:8px;
            ${icoCollect}
            background-position:-170px -117px;
        }
    }

`
export const ManageBox = styled.div`
    width:100%;
    margin-bottom:20px;
    border:1px solid ${colors.geryC};
    border-radius:5px;
    box-shadow:6px 6px 10px rgba(0,0,0,.1);
    .box_in{
        padding:26px 30px;
        line-height:1.6;
        ${size.ft14}
        .btn{
            display:block;
            margin:14px 0;
            padding:0;
            ${weight.bold};
        }
        i{
            ${icoStyle}
            background-position:-32px -144px;
            height:18px;1q
            margin-top:-3px;
            
        }
    }
    .btn_box{
        display:block;
        width:100%;
        line-height:34px;
        text-align:center;
        ${size.ft14}
        ${weight.bold};
        border-top:1px solid ${colors.geryC};
    }
    .state{
        color:#0eb653;
    }
`
export const BestBoardStyle = styled.div`
    margin:40px 0;
    h2{
        margin-bottom:26px;
        ${size.ft18}
        ${weight.bold};
    }
    
`
export const BestBoardList = styled.ul`
    li{
        margin-bottom:12px;
        .writer{
            padding-left:10px;
            color:${colors.grey6};
        }
    }
    a{
        display:block;
        position:relative;
        padding-bottom:10px;
        padding-left:10px;
        ${size.ft16}
        ${ellipsis.default}
        ${MouseOver.default}
        &:before{
            content:"";
            width:4px; 
            height:4px;
            position:absolute;
            top:6px;
            left:0;
            ${rdSize.round}
            background-color:#c8c8c8;
        }
    }
    
`
export const CaseBoardList = styled.div`
a{
    margin-bottom:14px;
    ${flexOpt.scb}
    padding:30px 20px 33px;
    border:1px solid ${colors.geryC};
    border-left:2px solid ${colors.blue};
    .board_cont{
        flex-basis:660px;
        .title{
            display:inline-block;
            padding-bottom:14px;
            ${size.ft20}
            ${weight.semiBold};
            ${MouseOver.default}
            ${ellipsis.default}
        }
        p{
            line-height:1.4;
            ${ellipsis.line2}
        }
    }
    &:hover{
        .title{
            text-decoration:underline;
        }
    }
    .info{
        margin-top:24px;
        padding-top:14px;
        border-top:1px solid ${colors.greyE1};
        &>span{
            position:relative;
            padding:0 8px;
            ${size.ft12};
            color:${colors.grey6};
        }
        span+span:before{
            content:"";
            width:1px;
            height:8px;
            background:${colors.geryC};
            ${PosCenterY}
            left:0;
        }
        .cnt{
            color:${colors.blue};
            ${weight.semiBold};
        }
    }
}

`

/*library */
export const NewsUl = styled.ul`
    li{
        line-height:52px;
        border-bottom:1px solid ${colors.greyE1};
        &>*{
            display: inline-block;
            padding:0 10px;
            box-sizing:border-box;
            vertical-align: middle;
        }
        span{
            width:14%;
            color:${colors.greyBb};
        }
        a{
            display: inline-block;
            width:86%;
            ${ellipsis.default}
            ${size.ft16};
            ${MouseOver.default}
        }
    }
`
interface ListProps {
    readonly type?: string,
}   
export const ListUl = styled.ul<ListProps>`
    display:flex;
    gap: ${({ type }) => (type==="evt" ? '40px 75px' : '26px')};
    flex-wrap:wrap;
    a{
        display:block;
        position:relative;
        border:1px solid ${colors.greyE1};
        ${rdSize.default}
        overflow:hidden;
        box-shadow:rgba(0, 0, 0, 0.1) 10px 10px 10px;
        &:hover{
            border:1px solid  ${colors.blue};
        }
        .cover{
            position:absolute;
            height:152px;
            inset:0;
            background:rgba(0, 0, 0, 0.6);
            ${size.ft18};
            color:#fff;
            ${weight.bold};
            display:flex;
            align-items:center;
            justify-content:center;
        }
    }

    ${({ type }) => type==="rsch" &&
        css`
        li{
            flex:0 0 calc(33.3% - 20px);
        }
        i{
            position:absolute;
            top:35px;
            right:30px;
            width:20px;
            height:20px;
            ${icoCollect}
            background-position:-128px -147px;
            text-indent:-9999px;
        }
        .info{
            padding:35px 30px 0px 40px;
            height:146px;
            .tit{
                margin-bottom:12px;
                ${size.ft22};
                ${weight.semiBold};
            }
            p{
                line-height:1.4;
                color:${colors.grey6};
                ${size.ft16};
            }
        }
        .logo_area{
            display: flex;
            align-items: center;
            justify-content: center;
            height:122px;
            background-color:#f9f9f9;
            box-sizing:border-box;
            .journal{
                display:block;
                height:65px;
                background:url('/images/txt_journal.png') no-repeat;
                &.logo1{
                    width:133px;
                    background-position-y:-70px;   
                }
                &.logo2{
                    width:190px;
                    background-position-x:-140px;   
                }
                &.logo3{
                    width:114px;
                    background-position-y:-130px;   
                }
                &.logo4{
                    width:87px;
                    background-position-y:-195px;   
                }
                &.logo5{
                    width:150px;
                    background-position: -140px -195px;
                }
                &.logo6{
                    width:234px;
                    background-position: -140px -260px;
                }
                &.logo7{
                    width:110px;
                    background-position-y: -260px;
                }
                &.logo8{
                    width:167px;
                    background-position-y: -325px;
                }
            }
        }
    `}
    ${({ type }) => type==="evt" &&
    css`
        li{
            flex:0 0 348px !important;
        }
        figcaption{
            height:120px;
            padding:23px 30px;
            box-sizing: border-box;
            strong{
                display:block;
                margin-bottom:20px;
                ${size.ft18};
                ${weight.bold};
            }
        }
    `}
    
   
`
;