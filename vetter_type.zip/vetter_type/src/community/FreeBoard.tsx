import SchInput from "common/SearchRow/SchInput";
import SelectBox from "common/SearchRow/SelectBox";
import { Container, ContainerWrap } from "common/common.style";
import { BestBoardList, BordWrapStyle, BrnWrite, VisualStyle } from "community/community.style";
import Visual from "library/Visual";
import { BtnMore, SchGroup } from "list/list.style";
import BoardComp from "./BoardComp";
import { Aside } from "aside/aside.style";
import Banner from "aside/Banner";
import WriteManage from "./WriteManage";


export default function FreeBoard() {
    const select_list = [
        { label: '제목', value: 'title' },
        { label: '제목+내용', value: 'total' },
        { label: '내용', value: 'content' }
    ];
    return(
        <ContainerWrap id="content" pdType0={true}>
            <VisualStyle type="freeboard">
                <Visual title="자유게시판" sub_title="회원들과 자유롭게 이야기를 나누고, 함께 만들어가는 공간입니다."></Visual>
            </VisualStyle>
            <Container>
                <div className="inner_box">
                    <BordWrapStyle type="freeboard">
                        <SchGroup className="sch_area bt_gray">
                            <li className="sel">
                                <SelectBox selectList={select_list} />
                            </li>
                            <li className="sch">
                                <SchInput />
                            </li>
                        </SchGroup>
                        <BoardComp />
                        <BtnMore>더보기 1/5</BtnMore>
                        <BrnWrite>
                            <button>게시글 작성</button>
                        </BrnWrite>
                    </BordWrapStyle>
                </div>
                <Aside>
                    <WriteManage />
                    <BestBoardList />
                    <div>
                        <Banner type="banner1"/>
                    </div>
                </Aside>
            </Container>

        </ContainerWrap>
    )
}