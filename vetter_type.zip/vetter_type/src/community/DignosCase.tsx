import { Container, ContainerWrap } from "common/common.style";
import { BordWrapStyle, VisualStyle } from "./community.style";
import Visual from "library/Visual";
import { BtnMore, ListOptStyle, ListSort, SchGroup } from "list/list.style";
import SchInput from "common/SearchRow/SchInput";
import CaseBoard from "./CaseBoard";
import { Aside } from "aside/aside.style";
import AsideList from "aside/AsideList";
import Banner from "aside/Banner";

export default function DignosCase() {
    return(
        <ContainerWrap id="content" pdType0={true}>
            <VisualStyle type="case">
                <Visual title="진단케이스" sub_title="임상에 도움이 되는 다양한 진단케이스와 처방 노하우, 처방 가이드를 제공합니다."></Visual>
            </VisualStyle>
            <Container>
                <div className="inner_box">
                    <BordWrapStyle>
                        <SchGroup className="sch_area">
                            <li>
                                <SchInput inputHolder="검색" />
                            </li>
                        </SchGroup>  
                        <ListOptStyle>
                            <strong>전체(10)</strong>
                            <div className="right">
                                <ListSort>
                                    <a href="#none" className="on">최신순</a>
                                    <a href="#none">조회순</a>
                                </ListSort>
                            </div>
                        </ListOptStyle>
                        <CaseBoard />
                        <CaseBoard />
                        <BtnMore>더보기 1/5</BtnMore>
                    </BordWrapStyle>
                </div>
                <Aside>
                    <div>
                        <AsideList presenter="이정은 교수 (ㅇㅇㅇ병원 00내과)"/>
                    </div>
                    <div>
                        <Banner type="banner1"/>
                    </div>    
                </Aside>
            </Container>
        </ContainerWrap>
    )
}