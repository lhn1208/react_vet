import { AdBanner } from "common/common.style";

export const TopBanner = () => {
    return (
        <AdBanner href="#none" className="contents_w">
            <img src={'/images/main_banner.jpg'} alt="베터빌 배너"/>
        </AdBanner>
    );
};  