import {FONTSTYLE } from 'styles/fontStyle';
import {LabelStyle, colors, contWidth, flexOpt, ellipsis, MouseOver, ScrollStyle, Transition, PosCenterY, icoStyle, icoCollect} from 'styles/variables';

export const customStyles = {
    font: {
        size: FONTSTYLE.size,
        weight: FONTSTYLE.weight
    },
    LabelStyle: {
        rdSize: LabelStyle.rdSize,
        border: LabelStyle.border,
        labeBg: LabelStyle.labeBg,
    },

    contWidth: contWidth,
    flexOpt: flexOpt, 
    colors: colors,
    icoCollect:icoCollect,
    ellipsis:ellipsis,
    MouseOver:MouseOver,
    ScrollStyle:ScrollStyle,
    Transition:Transition,
    PosCenterY:PosCenterY,
    // bgCollect:bgCollect,
    icoStyle:icoStyle,
    
}