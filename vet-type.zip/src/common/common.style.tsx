import styled from '@emotion/styled';
// import { Global, css } from '@emotion/react';
import { customStyles } from 'common/custom.style';
const { size, weight } = customStyles.font;
const {contWidth}  = customStyles;


interface ContainerProps {
    readonly primary?: boolean;
}   
  
export const ContainerWrap = styled.div<ContainerProps>`
    .h2_title{margin-bottom:24px;}
    padding:70px 0 30px;
    background-color: ${props => (props.primary ? '#f5f5fa' : '#fff')};
    .contents_w{
        max-width:1200px;
        width:100%;
        margin:0 auto;
    }
    h2,h3,h4{ ${weight.bold}}
   
`
interface PdProps {
    readonly pdType0?: boolean;
}   
  
export const Container=styled.div<PdProps>`
    display:flex;
    position:relative;
    justify-content:space-between; 
    ${contWidth}
    padding-top: ${props => (props.pdType0 ? '0': "60px")};
    
    padding-bottom:40px;
    .inner_box{
        flex-basis:865px;
        max-width:865px;
    }
`
export const AdBanner = styled.a`
    margin-top:30px;
    display:block;
    
`
export const SectionList=styled.section`
    &+section{
        margin-top:40px;
    }
`
export const TitleContainer=styled.h2`
    margin:20px 0;
    ${size.ft22}
    i{
        margin-left:10px;
    }
`