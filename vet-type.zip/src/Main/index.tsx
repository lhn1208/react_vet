import { Aside } from "aside/aside.style";
import { SectionList, Container, ContainerWrap } from "common/common.style";
import { TopBanner } from "common/TopBanner";
import { KeyWordPick } from "./KeyWordPick";
import { Title } from "common/Title";
import { ListSec } from "list/ListSec";
import { ListSec2 } from "list/ListSec2";
import { BtnMore } from "list/list.style";
import News from "aside/News";
import Services from "aside/Services";
import Banner from "aside/Banner";

export const Main = () => {
  return (
  <>
    <ContainerWrap primary={true} id="content">
      <TopBanner />
      <Container>
        <div className="inner_box">
          <KeyWordPick />
          <SectionList>
            <Title label="임상강좌 VOD" />
            <ListSec type="vod" />
          </SectionList>
          <SectionList>
            <Title label="LIVE 세미나" />
            <ListSec type="live" />
          </SectionList>
        </div>
        <Aside>
          <News />
          <Services />
          <div>
              <Banner type="banner1"/>
              <Banner type="banner2"/>
          </div>
        </Aside>
      </Container>
    </ContainerWrap>
    <ContainerWrap>
      <Container pdType0={true}>
        <div className="inner_box">
          <Title label="추천 콘텐츠" />
          <ListSec2 />
          <BtnMore>더보기 1/5</BtnMore>
        </div>
      </Container>
    </ContainerWrap>
  </>
  );
};  