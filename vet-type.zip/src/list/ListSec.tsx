import { ListStyle } from "list/list.style";
import { ListAlbum } from "list/ListAlbum";

interface ListSecProps {
    readonly type: string;
}
  
export const ListSec= ({ type }:ListSecProps) => {
    return (
        <ListStyle>
            <ListAlbum type={type} />
        </ListStyle>
    );
};  