import list_recomm from 'data/list_recomm';
import { DataNone, IcoSch, ListItem, ListType } from './list.style';
interface ListSecProps {
    readonly type: string;
}
  
export const Recomm= ({ type }:ListSecProps) => {
    return (
        <>
            {type === "album" && list_recomm.length > 0 && (
                <ListType col="col2">
                    {list_recomm.map((item, index) => (
                        <ListItem key={index}>
                            <a href={item.link}>
                                <figure>
                                    <img src={item.img} alt={item.alt} />
                                </figure>
                                <figcaption>
                                    <span className="classify">{item.classify}</span>
                                    <strong className="title">{item.desc} </strong>
                                </figcaption>
                            </a>
                        </ListItem>
                    ))}
                </ListType>
            )}
            {type === "list" && list_recomm.length > 0 && (
                <ListType col="col1">
                    {list_recomm.map((item, index) => (
                        <ListItem key={index}>
                            <a href={item.link}>
                                <figure>
                                    <img src={item.img} alt={item.alt} />
                                </figure>
                                <figcaption>
                                    <span className="classify">{item.classify}</span>
                                    <strong className="title">{item.title} </strong>
                                    <strong className="desc">{item.desc} </strong>
                                </figcaption>
                            </a>
                        </ListItem>
                    ))}
                </ListType>
            )}
            {!(type === "album" && list_recomm.length > 0) && !(type === "list" && list_recomm.length > 0) && (
                <DataNone>
                    <IcoSch></IcoSch>데이터가 없습니다.
                </DataNone>
            )}     
        </>
    );
};  