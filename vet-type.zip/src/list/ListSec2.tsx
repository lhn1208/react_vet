import ListSelectSet from "./ListSelectSet";
import { Recomm } from "./Recomm";
import { useState } from "react";

export const ListSec2= () => {
    //showCol1 상태의 현재값(초기값) = true,
    //setShowCol1은 상태 값을 업데이트하는 함수
    const [showCol, setShowCol] = useState(true);
    const toggleShowCol = () => {
        setShowCol(!showCol);
    };
    return (
        <>
            <ListSelectSet showCol={showCol} toggleShowCol={toggleShowCol} />
            {showCol ? (
                <Recomm type="album" />
            ):(
                <Recomm type="list" />
            )}
        </>
    );
};  