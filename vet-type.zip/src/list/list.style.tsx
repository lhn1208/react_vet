import styled from '@emotion/styled';
import { css } from '@emotion/react';
import { customStyles } from 'common/custom.style';
const { size, weight } = customStyles.font;
const {rdSize, border, labeBg} = customStyles.LabelStyle;
const {ellipsis,colors,PosCenterY,flexOpt,icoCollect}  = customStyles;

export const ListStyle = styled.div`
    position:relative;
    h2{
        margin-bottom:24px;
    }
`
interface ContainerProps {
    readonly col?: string;
  }
export const ListType = styled.ul<ContainerProps>`
    display: grid;
    gap:26px 16px;
    grid-template-columns:${props => {
        if (props.col === 'col2') {
            return 'repeat(2, 1fr)';
        } else if (props.col === 'col3') {
            return 'repeat(3, 1fr)';
        } else {
            return 'repeat(1, 1fr)';
        }
    }};
    li{
        figure{
            margin-bottom:10px;
            position:relative
        }
        .title{
            display:block;
            margin-top:10px;
            line-height:1.4;
            ${size.ft16};
            ${weight.normal};
            ${ellipsis.line2};
            
        }
        .title+:is(.presenter,.date){
            margin-top:6px;
            ${size.ft14};
            color: ${colors.grey6};
        }
        a:hover{
            .title{
                text-decoration: underline;
            }
        }
    }
    ${props => props.col === 'col1' && css`
       a{
            display:flex;
            gap:20px;
       }
    ` }
    figcaption{
        flex-basis:568px;
        max-width:568px;
    }
    .point{
        margin-top:10px;
        padding-left:18px;
        line-height:1.4;
        ${size.ft14};
        position:relative;
        ${ellipsis.default};
        &:before{
            content:"";
            display:inline-block;
            width:14px;
            height:14px;
            text-align:center;
            background-position:-114px -30px;
            ${PosCenterY};
            left:0;
            margin-top:1px;
        }
    }
`
interface LabelProps {
    $mode?: "gradient" | "orange";
    className?: string;
    cate?:string;
  }

  
export const Label = styled.i<LabelProps>`
    display:inline-block;
    vertical-align: middle;
    height:20px;
    line-height:20px;
    font-style:normal;
    &.en{
        line-height:18px;
    }
    padding:0 8px;
    ${rdSize.default}
    &+i{
        margin-left:4px;
    }
    ${size.ft12};
    ${(props) => {
        switch (props.$mode) {
            case "gradient":
            return css`
                ${labeBg.gradient};
            `;
            case "orange":
            return css`
                ${labeBg.orange};
            `;
            default:
            return css`
                ${border.blueSolid};
            `;
        }
    }}
    ${props => props.cate  === 'cate' && css`
        position:absolute;
        bottom:12px;
        left:12px;
        ${labeBg.boldGreen};
        border:none;
    ` }
    
`
export const ListItem = styled.li`
    a{
        display:flex;
        align-items:center;
        gap:20px;
        figure{
            flex-basis:191px;
            margin-bottom:0;
        }
        figcaption{
            
        }
        .classify{
            font-size:16px;
            ${weight.bold};
        }
        .desc{
            display:block;
            line-height:1.2;
            margin-top:4px;
            color:${colors.grey6};
            ${size.ft16};
            ${weight.normal};
        }
    }

`
export const DataNone= styled.div`
    display:flex;
    height:26vh;
    align-items:center;
    justify-content:center;
    ${size.ft24};
    i{
        margin-right:4px;
    }
`
export const IcoSch = styled.i`
    display:inline-block;
    width:24px;
    height:30px;
    background-position:-33px 7px;
`

export const ListSet = styled.div`
    position:absolute;
    top:3px; 
    right:0;
    button{
        width:16px;
        height:16px;   
        ${icoCollect};
        background-position:0px -30px;
        &.album{
            &.on{
                background-position-x:-22px;
            }
        }
        &.list{
                background-position-x:-44px;
            &.on{
                background-position-x:-67px;
            }
        }
        &:last-of-type{
            margin-left:10px;
        }
    }
`
export const BtnMore = styled.button`
    display:block;
    margin:40px auto 0px;
    padding:0 32px 0 16px;
    min-width:112px;
    line-height:30px;
    border:1px solid ${colors.greyE1};
    color: ${colors.greyA1};
    ${rdSize.default};
    font-size:14px;
    font-weight:500;
    position:relative;
    &:after{
        content:"";
        position:absolute;
        top:34%;
        right:10px;
        display:inline-block;
        vertical-align:3px;
        width:5px;
        height:5px;
        margin-left:10px;
        border-left:2px solid ${colors.greyA1};
        border-bottom:2px solid ${colors.greyA1};
        transform:rotate(-45deg);
      }
`
export const SchGroup = styled.ul`
    margin-bottom:20px;
    padding-bottom:10px;
    height:34px;
    border-bottom:1px solid #111;
    display: flex;
    align-items: center;
    gap:10px;
    li{
        position:relative;
        flex:1 0;
        &>*{
            position:relative;
            line-height:34px;
            height:34px;
            ${size.ft16};
            box-sizing:border-box;
        }
        select{
            padding-right:20px;
            border:none;
            ${weight.bold};
        }
    }
   
    li+li{
        padding-left:6px;
        &:before{
            content:"";
            display:block;
            width:1px;
            height:10px;
            background:#111;
            ${PosCenterY};
            left:0;
        }
    }
`
export const DateInputStyle = styled.div`
    display:flex;
    input[type="text"]{
        width:114px;
        padding:0px 10px;
        box-sizing:border-box;
        font-family:var(--base-font);
         ${size.ft16};
    }

`
export const SchInputStyle = styled.div`
    width:355px;
    margin-left:10px;
    box-sizing:border-box;
    input[type="text"]{
        width:90%;
        height:100%;
        padding:0 10px;
        ${size.ft16};
        box-sizing:border-box;
    }
    .btn{
        ${PosCenterY};
        right:4px;
        width:20px;
        height:100%;
        background-position:-67px 8px;
        text-indent:-9999em;
    }
`
export const ListOptStyle=styled.div`
    position:relative;
    line-height:36px;
    ${flexOpt.scbAlignCenter}
    margin-bottom:6px;
    strong{
        ${size.ft16};
    }
`
export const ListSort = styled.div`
    a{
        &.on{
            ${weight.bold};
        }
        padding:0 6px;
        color:${colors.grey6};
        ${size.ft14};
    }
`
;