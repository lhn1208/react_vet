import { SvStyle } from "./aside.style";

export default function Services() {
    return(
        <SvStyle>
            <h2 className="h2_title">Service</h2>
            <ul>
                <li><a href="#none">계산기</a></li>
                <li><a href="#none" className="case">진단케이스</a></li>
                <li><a href="#none" className="report">논문검색</a></li>
            </ul>
        </SvStyle>
           
    )

}