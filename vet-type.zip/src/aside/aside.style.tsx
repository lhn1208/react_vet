import styled from '@emotion/styled';
import { customStyles } from 'common/custom.style';
const { size, weight } = customStyles.font;
const {ellipsis,MouseOver,icoCollect}  = customStyles;

export const Aside = styled.aside`

    flex-basis:270px; 
    max-width:270px;
    >div{
        margin-bottom:40px;
        &:last-of-type{
            margin-bottom:0;
        }
    }
    .h2_title{
        margin-bottom:26px;
        ${size.ft18};
        ${weight.bold};
    }
`

export const NewsStyle = styled.div`
    position:relative;
    li{
        line-height:1.8;
        a{
            display:block;
            width:100%;
            ${size.ft14};
            ${ellipsis.default};
            ${MouseOver.default};
        }
    }
`
export const SvStyle =styled.div`
    ul{
        display:flex;
        gap:14px;
        li{
            width:calc(33.3% - 7px);
            a{
                display:block;
                ${size.ft16};
                ${weight.bold};
                text-align:center;
                &:before{
                    content:"";
                    display:block;
                    width:56px;
                    height:48px;
                    margin:0 auto 10px;
                    ${icoCollect};
                    background-position:10px -61px;
                }
                &.case:before{
                    background-position:-54px -63px;
                }
                &.report:before{
                    background-position:-115px -67px;
                }
            }
        }
    }
`
export const BannerItem =styled.a`
    display:block;
    margin-bottom:10px;
`

export const List = styled.a`
    display:flex;
    gap:10px;
    .title{
        line-height:1.2;
        ${ellipsis.line2};
        ${MouseOver.default};
        ${weight.normal};
    }
    .txt_small{
        margin-top:4px;
        ${size.ft12};
    }
`
;