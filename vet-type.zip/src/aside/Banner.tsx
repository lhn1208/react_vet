import { BannerItem } from "./aside.style";

interface Props {
    readonly type: string;
}
  

export default function Banner({type}:Props){
 return <>
    <BannerItem href="#none">
        {type==="banner1" && ( <img src={'/images/banner_right.jpg'} alt=""></img>)}
        {type==="banner2" && ( <img src={'/images/banner_topic.jpg'} alt=""></img>)}
    </BannerItem>
 </>
 

}