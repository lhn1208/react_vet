const select_list1 = [
    {
       opt1:'질환군',
       opt2:'피부',
       opt3:'호흡기질환'
    },
]
export default select_list1;