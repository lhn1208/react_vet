import ListSelectSet from "../list/ListSelectSet";
import { ContainerWrap} from "../common/common.style";
import { BtnMore, ListSec } from "../list/list.style";
import ListAlbum from "../list/ListAlbum";
import Recomm from "../list/Recomm";
import { Pick } from "./main.style";
import { useState } from "react";
import { Aside } from "../aside/aside.style";
import News from "../aside/News";
import Services from "../aside/Services";
import Banner from "../aside/Banner";
import TopBanner from "../common/TopBanner";


export default function Main() {
    //showCol1 상태의 현재값(초기값) = true,
    //setShowCol1은 상태 값을 업데이트하는 함수
    const [showCol1, setShowCol1] = useState(true);
    const toggleShowCol1  = () => {
        setShowCol1(!showCol1);
    };
    return (
        <>
        <ContainerWrap primary="true">
            <TopBanner />
            <div className="container">
                <div className="inner_box">
                    <Pick>
                        <strong>Pick</strong>
                        <a href="#none">#초음파아카데미</a>
                        <a href="#none">#이벤트</a>
                        <a href="#none">#이달의심사이슈</a>
                        <a href="#none">#보험심사청구</a>
                        <a href="#none">#컨설팅</a>
                    </Pick>
                    <ListSec id="content">
                        <h2 className="h2_title">임상강좌 <i>VOD</i></h2>
                        <ListAlbum type="vod" />
                    </ListSec>
                    <ListSec>
                        <h2 className="h2_title"><i>Live</i> 세미나</h2>
                        <ListAlbum type="live" />
                    </ListSec>
                </div>
                <Aside>
                    <News />
                    <Services />
                    <div>
                        <Banner type="banner1"/>
                        <Banner type="banner2"/>
                    </div>
                </Aside>
            </div>
        </ContainerWrap>
        <ContainerWrap>
            <div className="container">
                <div className="inner_box">
                    <ListSec>
                        <h2 className="h2_title">추천 콘텐츠</h2>
                        <ListSelectSet showCol1={showCol1} toggleShowCol1={toggleShowCol1} />
                        {showCol1 ? (
                            <Recomm type="album" />
                        ):(
                            <Recomm type="list" />
                        )}
                        <BtnMore>더보기 1/5</BtnMore>
                    </ListSec>
                </div>
                <Aside>
                    <div>
                        <Banner type="banner1"/>
                        <Banner type="banner2"/>
                    </div>             
                </Aside>
            </div>
        </ContainerWrap>
        </>
    );
}