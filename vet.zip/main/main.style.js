import styled from '@emotion/styled'
import { customStyles } from '../common/custom.style';
const { size, weight } = customStyles.font;
const {rdSize} = customStyles.LabelStyle;
const {colors}  = customStyles;

export const Pick = styled.div`
    margin:20px 0px 40px;
    & > strong{
        margin-right:6px;
        color:${colors.blue};
        ${size.ft20};
        ${weight.bold};
        font-style:italic;
    }

    a{
        margin:0 8px;
        padding:4px 10px;
        ${size.ft13};
        ${weight.medium};
        color:${colors.grey6};
        background-color:${colors.greyE6};
        ${rdSize.default}
    }
`