import { DateInputStyle } from "./list.style";
export default function DateInput (){
    return(
       <DateInputStyle>
            <input type="text" title="날짜를 입력하세요." placeholder="YYYY-MM-DD"></input>
            -
            <input type="text" title="날짜를 입력하세요." placeholder="YYYY-MM-DD"></input>
       </DateInputStyle>
    )

}