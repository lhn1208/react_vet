import { ListType, ListItem, DataNone, IcoSch } from "./list.style";
import list_recomm from '../data/list_recomm';
export default function Recomm({ type }) {
    return (
        <>
            {type === "album" && list_recomm.length > 0 && (
                <ListType col2="true">
                    {list_recomm.map((item, index) => (
                        <ListItem key={index}>
                            <a href={item.link}>
                                <figure>
                                    <img src={item.img} alt={item.alt} />
                                </figure>
                                <figcaption>
                                    <span className="classify">{item.classify}</span>
                                    <strong className="title">{item.desc} </strong>
                                </figcaption>
                            </a>
                        </ListItem>
                    ))}
                </ListType>
            )}
            {type === "list" && list_recomm.length > 0 && (
                <ListType col1="true">
                    {list_recomm.map((item, index) => (
                        <ListItem key={index}>
                            <a href={item.link}>
                                <figure>
                                    <img src={item.img} alt={item.alt} />
                                </figure>
                                <figcaption>
                                    <span className="classify">{item.classify}</span>
                                    <strong className="title">{item.title} </strong>
                                    <strong className="desc">{item.desc} </strong>
                                </figcaption>
                            </a>
                        </ListItem>
                    ))}
                </ListType>
            )}
            {!(type === "album" && list_recomm.length > 0) && !(type === "list" && list_recomm.length > 0) && (
                <DataNone>
                    <IcoSch></IcoSch>데이터가 없습니다.
                </DataNone>
            )}     
        </>
    );
}