import { SchInputStyle } from "./list.style";
export default function SchInput ({inputHolder}){
   const placeholderText = inputHolder ? inputHolder : '직접 입력하세요';
    return(
       <SchInputStyle className="sch_box">
          <input type="text" placeholder={placeholderText}></input>
          <button className="btn">검색</button>
       </SchInputStyle>
    )

}