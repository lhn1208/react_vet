import { ListSet } from "./list.style";
export default function Recomm({ showCol1, toggleShowCol1 }) {
    return (
        <ListSet>
            <button className={showCol1 ? 'on' : ''} onClick={toggleShowCol1}></button>
            <button className={!showCol1 ? 'on' : ''} onClick={toggleShowCol1}></button>
        </ListSet>
    )}