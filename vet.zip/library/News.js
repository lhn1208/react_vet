import Banner from "../aside/Banner";
import { Aside } from "../aside/aside.style";
import { ContainerWrap } from "../common/common.style";
import { BordWrapStyle, Visual } from "../community/commut.style";
import DateInput from "../list/DateInput";
import SchInput from "../list/SchInput";
import { BtnMore, SchGroup } from "../list/list.style";
import NewsBoard from "./NewsBoard";

export default function News() {
    return(
        <ContainerWrap id="content">
            <Visual news>
                <div className="visual_inner">
                    <h2>베터빌 뉴스</h2>
                    <p>수의학계 각종 현안 및 관심사와 연관된 최신 뉴스를 제공합니다.</p>
                </div>
            </Visual>
            <div className="container">
                <div className="inner_box">
                    <BordWrapStyle news>
                        <SchGroup>
                            <li className="sel">
                                <DateInput />
                            </li>
                            <li className="sch">
                                <SchInput />
                            </li>
                        </SchGroup>  
                        <NewsBoard />
                        <BtnMore>더보기 1/5</BtnMore>
                    </BordWrapStyle>
                </div>
                <Aside>
                    <div>
                        <Banner type="banner1"/>
                    </div>
                </Aside>
            </div>
        </ContainerWrap>
    )
}