import { NewsUl } from "../community/commut.style";

export default function NewsBoard() {
    return(
        <NewsUl>
            <li>
                <span className="date">2022.05.06</span>
                <a href="#none">'길고양이 TNR, 마당개 중성화 문제 많다' 수의사회 보이콧 움직임</a>
            </li>
            <li>
                <span className="date">2022.05.06</span>
                <a href="#none">NSIAD 사용에 따른 Ulcer 예방을 위한 처방증례 Ulcer 예방을 위한 처방증례 Ulcer 예방(정제, 캡슐제, 과립자) NSIAD 사용에 따른 Ulcer 예방을 위한 처방증례 Ulcer 예방을 위한 처방증례 Ulcer 예방(정제, 캡슐제, 과립자) NSIAD 사용에 따른 Ulcer 예방을 위한 처방증례 </a>
            </li>
            <li>
                <span className="date">2022.05.06</span>
                <a href="#none">'길고양이 TNR, 마당개 중성화 문제 많다' 수의사회 보이콧 움직임</a>
            </li>
            <li>
                <span className="date">2022.05.06</span>
                <a href="#none">NSIAD 사용에 따른 Ulcer 예방을 위한 처방증례 Ulcer 예방을 위한 처방증례 Ulcer 예방(정제, 캡슐제, 과립자) NSIAD 사용에 따른 Ulcer 예방을 위한 처방증례 Ulcer 예방을 위한 처방증례 Ulcer 예방(정제, 캡슐제, 과립자) NSIAD 사용에 따른 Ulcer 예방을 위한 처방증례 </a>
            </li>
        </NewsUl>
    )
}