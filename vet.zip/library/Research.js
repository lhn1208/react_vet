import { ContainerWrap,FullContent } from "../common/common.style";
import { ListUl, Visual } from "../community/commut.style";

export default function Research() {
    return(
        <ContainerWrap id="content">
             <Visual report>
                <div className="visual_inner">
                    <h2>논문검색</h2>
                    <p>국내외 다양한 논문검색 채널을 제공합니다.</p>
                </div>
            </Visual>
            <FullContent>
                <ListUl rsch>
                    <li>
                        <a href="#none">
                            <i>바로가기 아이콘</i>
                            <div className="info">
                                <h3 className="tit">PubMed</h3>
                                <p>미국 국립의학도서관(NLM)에서 제공하는
                                    <br/>최대 규모 서지 데이터베이스인 
                                    <br/>MEDLINE 검색 엔진
                                </p>
                            </div>
                            <div className="logo_area">
                                <span className="journal logo1"></span>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="#none">
                            <i>바로가기 아이콘</i>
                            <div className="info">
                                <h3 className="tit">Google Scholar</h3>
                                <p>전 세계 학술 연구 관련<br />데이터 제공</p>
                            </div>
                            <div className="logo_area">
                                <span className="journal logo2"></span>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="#none">
                            <i>바로가기 아이콘</i>
                            <div className="info">
                                <h3 className="tit">NDSL</h3>
                                <p>과학기술정보의 전자도서관으로<br />지식발견형 검색서비스 제공</p>
                            </div>
                            <div className="logo_area">
                                <span className="journal logo3"></span>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="#none">
                            <i>바로가기 아이콘</i>
                            <div className="info">
                                <h3 className="tit">RISS</h3>
                                <p>한국교육학술정보원에서 제공하는<br />학술연구정보화 시스템</p>
                            </div>
                            <div className="logo_area">
                                <span className="journal logo4"></span>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="#none">
                            <i>바로가기 아이콘</i>
                            <div className="info">
                                <h3 className="tit">Cochrane Library</h3>
                                <p>연구 및 임상에서 활용가능한 데이터 제공</p>
                            </div>
                            <div className="logo_area">
                                <span className="journal logo5"></span>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="#none">
                            <i>바로가기 아이콘</i>
                            <div className="info">
                                <h3 className="tit">NEJM</h3>
                                <p>세계 최고 권위의 저널 제공</p>
                            </div>
                            <div className="logo_area">
                                <span className="journal logo6"></span>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="#none">
                            <i>바로가기 아이콘</i>
                            <div className="info">
                                <h3 className="tit">JAMA</h3>
                                <p>미국의학협회에서 출판되는<br/>9종의 전문 임상 학술지 제공</p>
                            </div>
                            <div className="logo_area">
                                <span className="journal logo7"></span>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="#none">
                            <i>바로가기 아이콘</i>
                            <div className="info">
                                <h3 className="tit">THE LANCET</h3>
                                <p>영국 최고 권위의 저널 제공</p>
                            </div>
                            <div className="logo_area">
                                <span className="journal logo8"></span>
                            </div>
                        </a>
                    </li>
                </ListUl>
            </FullContent>
        </ContainerWrap>
    )
}