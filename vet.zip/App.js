import React from 'react';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import './styles/base.css';
import Main from './main/Main';
import Header from './common/Header';
//import Sample from './sample/Sample';
import { GlobalStyles } from './common/common.style';
import ClassMain from './class/ClassMain';
import ClassLive from './class/ClassLive';
import ClassVod from './class/ClassVod';
import News from './library/News';
import Research from './library/Research';
import FreeBoard from './community/FreeBoard';
import DignosCase from './community/DiagnosCase';
import Event from './community/Event';
import Footer from './common/Footer';
function App() {
  return (
    <BrowserRouter basename='/react_vetter'>
        <div className="App">
          <GlobalStyles />
          <Header />
          <Routes>  
            <Route path='/' element={<Main />} />
            <Route path='/class' element={<ClassMain />} />
            <Route path='/class/live' element={<ClassLive />} />
            <Route path='/class/vod' element={<ClassVod />} />
            <Route path='/library' element={<News />} />
            <Route path='/library/reportsch' element={<Research />} />
            <Route path='/community' element={<FreeBoard />} />
            <Route path='/community/dignos_case' element={<DignosCase />} />
            <Route path='/community/event' element={<Event />} />
          </Routes>
          <Footer />
        </div>
    </BrowserRouter>
  );
}

export default App;
