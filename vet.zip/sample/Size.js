import styled, {css} from 'styled-components';
import { StyledComponentProps } from 'styled-components';

const Input = styled.input.attrs((props: StyledComponentProps<{ $size?: string }>) => ({
    type: "text",
    $size: props.$size || "1em",
  }))`
    color: #BF4F74;
    font-size: 1em;
    border: 2px solid #BF4F74;
    border-radius: 3px;
    margin: ${props => props.$size};
    padding: ${props => props.$size};
  `;
  
  export default function Size() {
    return (
        <div>
        <Input placeholder="A small text input" />
        <br />
        <Input placeholder="A bigger text input" $size="2em" />
      </div>

    )}