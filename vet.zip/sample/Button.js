import styled from '@emotion/styled';
import { css } from '@emotion/react';

const StyledButton = styled.button`
    background-color: ${props => props.backgroundcolor || '#ccd'};
    color: #111;
    padding: 5px 10px;
    border: 0;
    border-radius: ${props => props.$border30 ? '30px' : '10px'};

    ${props => props.primary && css`
        color:#fff;
        background-color:#49e;
    ` }
    

`;
export const TomatoButton = styled(Button)`
  background: tomato;
  border-color: tomato;
`;


function Button(props) {
    return <StyledButton {...props} />;
}

export default Button;