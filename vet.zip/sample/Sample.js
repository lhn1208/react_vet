import Button, { TomatoButton } from "./Button";
import { createGlobalStyle } from 'styled-components';
import Chk from "./Chk";
import Size from "./Size";
import Theme from "./Theme";
import Theme_swap from "./theme_swap";
const GlobalStyles = createGlobalStyle`
    body{
        padding:20px;
    }
`

export default function Sample() {
    return (
        <div>
            <GlobalStyles />
          <Button>Test Button</Button>
          <Button $border30>Test Button</Button>
          <Button primary="true">primary Button</Button>
          <TomatoButton>Tomato Button</TomatoButton>
          <Button backgroundcolor="skyblue">Test Button</Button>
        {/* button 스타일과 동일하게 link에 스타일 적용*/}
        <Button as="a" href="#">Link with Button stylie</Button>
        <Theme />
        <Theme_swap />
        <Size/>
        <Chk/>
        </div>

      
    );
}