import { useState } from "react";
import doctorImg from "../images/doctor_sample1.png";
import { FigCaption } from "./class.style";

export default function InfoProfess() {
    const [isOpen, setIsOpen] = useState(false); 
    const handleToggle = () => {
        setIsOpen(!isOpen); // Toggle the state when the button is clicked
    };
    return(
        <li className={isOpen ? "open" : ""}>
            <figure>
                <img src={doctorImg} alt="" />
            </figure>
            <FigCaption>
                <strong className="name">최원석 교수</strong>
                <span className="belong">서울대학교 소화기질환연구소</span>
                <ul className="info_list">
                    <li>진료과 <span className="val blue">소화기 내과</span></li>
                    <li>진료분야 <span className="val blue">협심증,심근경색,급성심정지,관상동맥질환,협심증,심근경색,금성심정지</span>
                        <ul>
                            <li>- 現 분당서울대학교병원 내과 교수</li>
                            <li>- 現 Editorial board: Diabetes, Obesity and Metabolism</li>
                            <li>- Massachusetts General Hospital/Harvard Medical School</li>
                        </ul>
                    </li>
                </ul>
                <button className={isOpen ? "btn_more open" : "btn_more"} onClick={handleToggle}>더보기</button>
            </FigCaption>
        </li>
    )
}