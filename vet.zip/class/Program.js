import { ProgramBox } from "./class.style";
import doctorProfile from "../images/profile_img.jpg";

export default function Program() {
    return(
        <ProgramBox>
            <ul>
                <li><span className="time">00:25</span><span className="program">강의 소개</span></li>
                <li><span className="time">00:46</span><span className="program">Idiopathic 란?</span></li>
                <li><span className="time">02:36</span><span className="program">Outflow tract of Ventricle</span></li>
                <li><span className="time">03:21</span><span className="program">Bundle branch block pattern</span></li>
                <li><span className="time">04:10</span><span className="program">Axis</span></li>
                <li><span className="time">05:10</span><span className="program">RVOT와 Fascicular VT의 차이</span></li>
                <li><span className="time">05:49</span><span className="program">Outflow tract VT 정리</span></li>
                <li><span className="time">06:46</span><span className="program">Case1(15/M)</span></li>
            </ul>
            <img src={doctorProfile} alt=""></img>
        </ProgramBox>
    )
}