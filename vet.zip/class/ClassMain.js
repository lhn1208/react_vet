import { useState } from "react";
import Banner from "../aside/Banner";
import TopBanner from "../common/TopBanner";
import { Aside } from "../aside/aside.style";
import { ContainerWrap } from "../common/common.style";
import ListSelectSet from "../list/ListSelectSet";
import ListAlbum from "../list/ListAlbum";
import { BtnMore, ListSec, SchGroup,ListOptStyle } from "../list/list.style";
import SelectBox from "../list/SelectBox";
import DateInput from "../list/DateInput";
import SchInput from "../list/SchInput";
import AsideList from "../aside/AsideList";

export default function ClassMain() {
    const [showCol1, setShowCol1] = useState(true);
    const toggleShowCol1  = () => {
        setShowCol1(!showCol1);
    };
    const select_list1 = [
        { label: '질환군', value: 'disease' },
        { label: '피부', value: 'skin' },
        { label: '호흡기질환', value: 'respiratory' }
    ];
    
    const select_list2 = [
        { label: '연자명', value: 'actor1' },
        { label: '장재원', value: 'actor2' },
        { label: '이혜원', value: 'actress' }
    ];
    return(
        <ContainerWrap id="content">
             <TopBanner />
             <div className="container">
                <div className="inner_box">
                    <ListSec>
                        <h2 className="h2_title">임상강좌 <i>VOD</i></h2>
                        <SchGroup>
                            <li>
                                <DateInput />
                            </li>
                            <li>
                                <SelectBox selectList={select_list1} />
                            </li>
                            <li>
                                <SelectBox selectList={select_list2} />
                            </li>
                            <li>
                                <SchInput />
                            </li>
                        </SchGroup>
                        <ListOptStyle>
                            <strong>전체(3)</strong>
                            <div className="right">
                                <ListSelectSet showCol1={showCol1} toggleShowCol1={toggleShowCol1} />
                            </div>
                        </ListOptStyle>
                        {showCol1 ? (
                            <ListAlbum type="vod" />
                        ):(
                            <ListAlbum type="list" />
                        )}
                        <BtnMore>더보기 1/5</BtnMore>
                    </ListSec>
                </div>
                <Aside>
                    <div>
                        <AsideList
                            title="추천 VOD"
                            presenter="이정은 교수 (ㅇㅇㅇ병원 00내과)"
                        />
                    </div>
                    <div>
                        <Banner type="banner1"/>
                    </div>
                </Aside>
            </div>
        </ContainerWrap>
    );
}