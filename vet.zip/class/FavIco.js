import { StarIco, HeartIco } from "./class.style";

export default function FavIco({ type, className, onClick }) {
    return(
        <>
        {type === "star" && (
            /*props에 classname과 onclick 추가 */
            <StarIco
                className={className}
                onClick={onClick}
            >
            </StarIco>
        )}
        {type === "heart" && (
             <HeartIco
             className={className}
             onClick={onClick}
            >
            </HeartIco>
        )}
        </>
    )
}