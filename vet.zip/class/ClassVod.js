import AsideList from "../aside/AsideList";
import Banner from "../aside/Banner";
import TopBanner from "../common/TopBanner";
import { Aside } from "../aside/aside.style";
import { ContainerWrap, FlexBothEnds } from "../common/common.style";
import { ClassState, InfoContainer, ReView, VodInfo } from "./class.style";
import FavIco from "./FavIco";
import { useState } from "react";
import InfoProfess from "./InfoProfess";
import Program from "./Program";

export default function ClassVod() {
    const [isStarOpen, setStarOpen] = useState(false);
  
    const handleStarToggle = () => {
      setStarOpen(!isStarOpen);
    };

    return(
        <ContainerWrap id="content">
            <TopBanner />
            <div className="container">
                <div className="inner_box">
                    <h2 className="h2_title">다시보기 <i>VOD</i></h2>
                    <ReView>
                        <div className="video">
                            <iframe src="https://www.youtube.com/embed/MjS4x2JOEYQ" title="기미의 전문적인 치료방법 2탄 - 레이저 치료 방법" frameBorder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowFullScreen></iframe>
                        </div>
                        <VodInfo>
                            <div className="title_area">
                                <FlexBothEnds className="top">
                                    <span className="cate">심혈관 질환</span>
                                    {/*FavIco컴포넌트 classname과 onclick 전달 */}
                                    <FavIco type="star" className={isStarOpen ? "on" : ""} onClick={handleStarToggle}></FavIco>
                                </FlexBothEnds>
                                <strong className="title">
                                    순환기(인터벤션)반려동물의 아토바스타틴/에제티미브 효능 및 임상적 데이터 데이터 리뷰와 효능에 관한 강좌
                                </strong>
                                <div className="hash">
                                    <span>#협심증</span><span>#심근경색</span><span>#동맥경색</span>
                                </div>
                                <ClassState>
                                    <span>비공개</span><span className="waiting">대기중</span><span className="live">라이브</span>
                                </ClassState>
                            </div>
                            <div className="cont">
                                <ul>
                                    <li>영상 제공기간<span className="val">2022.01.26 ~ 2023.01.26</span></li>
                                    <li>강의자료<span className="val file_attach"><a href="#none">첨부파일명.pdf</a>/<a href="#none">첨부파일명.pdf</a></span></li>
                                    <li>다시보기<span className="val">제공하지 않음</span></li>
                                </ul>
                            </div>
                            <InfoContainer>
                                <ul className="box_list">
                                    <InfoProfess />
                                    <InfoProfess />
                                </ul>
                            </InfoContainer>
                            <Program />
                            <FavIco type="heart" className={isStarOpen ? "on" : ""} onClick={handleStarToggle}></FavIco>
                            <span className="fav_num">15</span>
                        </VodInfo>
                        <div className="net_guide">
                            <strong>화면이 자꾸 끊기시나요?</strong>
                            <ul>
                                <li>- 네트워크 상태가 불안정할 경우, 화면이 끊길 수 있습니다.</li>
                            </ul>
                        </div>
                    </ReView>
                    
                </div>
            <Aside>
                <div>
                    <AsideList
                        title="추천 VOD"
                        presenter="이정은 교수 (ㅇㅇㅇ병원 00내과)"
                    />
                </div>
                <div>
                    <Banner type="banner1"/>
                </div>
            </Aside>
        </div>
    </ContainerWrap>
    )
}