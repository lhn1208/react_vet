import styled from '@emotion/styled'
import { customStyles } from '../common/custom.style';
const { size, weight } = customStyles.font;
const { rdSize, border, labeBg } = customStyles.LabelStyle;
const {ellipsis,colors,icoCollect,PosCenterY}  = customStyles;
export const LiveSeminar = styled.div`
    .live_top{
        margin-top:40px;
        margin-bottom:10px;
        .btn{
            padding:0 10px;
            line-height:34px;
            ${size.ft16};
            color:#111;
            border:1px solid #111;
        }
    }
`
export const LiveTable = styled.div`
    table{
        width:100%;
        border-top:1px solid #111;
        th,td.time{
            padding:28px 4px;
            ${size.ft16};
            vertical-align:top;
            text-align:center;
            strong{
                display:block;
            }
        }
        th{
            .week{
                margin-top:2px;
            }
        }
        td.time{
            &.purple{
                background-color:#ecf0f9;
                color:#6b93d4;
            }
            &.green{
                background-color:#eaf8f5;
                color:#45c1a2;
            }
        }
        a{  
            display:block;
            padding:28px 100px 28px 16px;
            position:relative;
            border-bottom:1px solid ${colors.greyE1};
            .cate_class{
                display:block;
                margin-bottom:10px;
            }
            .pro_title{
                display:block;
                width:576px;
                ${ellipsis.default};
                ${size.ft18};
                ${weight.bold};
                i{
                    margin-right:4px;
                }
            }
            .presenter{
                display:block;
                margin:4px 0;
            }

            .apply{
                position:absolute;
                right:0;
                ${PosCenterY};
                .state{
                    padding:0px 16px;
                    line-height:26px;
                    text-align:center;
                    ${rdSize.default}
                    ${weight.bold}  
                    ${border.greySolid};
                    &.possible{
                        ${labeBg.gradient}
                        color:#fff;
                        border:none;
                    }
                }
                .people{
                    margin-top:4px;
                    span{
                        color:${colors.greyA1};
                    }
                }
            }
        }
    }
`
export const LiveGuideGrp = styled.div`
    &>span{
        position:relative;
        margin-right:16px;
        padding-left:14px;
        &+span:before{
            content:"";
            ${PosCenterY}
            left:0;            
            width:1px;
            height:14px;
            background:${colors.greyE1};
        }
        i{
           margin-top:-2px;
        }
    }
`
export const IcoLabel = styled.i`
    display:inline-block;
    width:18px;
    height:18px;
    line-height:16px;
    background-color:#ff6879;
    color:#fff;
    text-align:center;
    box-sizing:border-box;
    vertical-align:middle;
    font-style:normal;
    ${size.ft12}
    &.purple{
        background-color:#866ae2;
    }
`
export const ClassState = styled.div`
    margin:12px 0;
    span{
        display: inline-block;
        margin-right:4px;
        padding:0 7px;
        line-height:24px;
        ${size.ft12};
        color: ${colors.grey6}; 
        border:1px solid ${colors.greyE1};
        &.waiting{
            color: ${colors.purple};
            border:1px solid ${colors.purple};
        }
        &.live{
            color: ${colors.blue};
            border:1px solid ${colors.blue};
        }
    }

`
export const ReView = styled.div`
    .video{
        width:100%;
        height:487px;
        overflow:hidden;
        margin-bottom:40px;
        iframe
        {
            width:100%;
            height:100%;
        }
    }
    .net_guide{
        margin:20px 0 40px;
        strong{
            display:block;
            position:relative;
            margin-bottom:12px;
            padding-left:28px;
            ${size.ft16};
            &:before{
                content:"";
                ${PosCenterY};
                left:0;
                width:18px;
                height:18px;
                ${icoCollect};
                background-position:-32px -117px;
            }
        }
        padding:20px;
        border:1px solid ${colors.greyE1};
    }
`
export const VodInfo=styled.div`
    .title_area{
        .top{
            .cate{
                padding:0px 10px;
                line-height:22px;
                ${rdSize.default}
                ${weight.bold}  
                ${border.blueSolid};
                ${size.ft14};
            }
        }
       .title{
            margin:8px 0px;
            ${ellipsis.line2};
            ${size.ft24};
            ${weight.medium};
            line-height:1.4;
       }
       .hash{
            span{
                display: inline-block;
                margin-right:4px;
                ${weight.normal};
                color:${colors.grey6};
            }
       }
    }
    .cont{
        margin:30px 0 40px;
        li{
            margin-bottom:6px;
            ${size.ft14};
            color:${colors.grey6};
            .val{
                margin-left:12px;
                color:#000;
            }
            .file_attach{
                a{
                    text-decoration:underline;
                }
            }
        }
    }
    .fav_num{
        display:block;
        text-align:center;
    }
`
export const StarIco = styled.button`
    display: inline-block;
    width:26px;
    height:26px;
    padding:10px;
    ${icoCollect};
    background-position:-202px -59px;
    border:1px solid ${colors.greyE1};
    &.on{
        background-position:-228px -60px;
    }
`
export const HeartIco = styled.button`
    display: block;
    margin:0 auto;
    width:22px;
    height:20px;
    ${icoCollect};
    background-position:-214px -94px;
    &.on{
        background-position-x:-177px;
    }
`
export const InfoContainer = styled.div`
    .box_list>li{
        &:first-of-type{
            border-top:1px solid ${colors.greyE1};
        }
        position:relative;
        display: flex;
        gap:20px;
        padding:20px 0 10px;
        border-bottom:1px solid ${colors.greyE1};
        height:120px;
        overflow:hidden;
        &.open{
            height:auto;
        }
    }
`
export const FigCaption=styled.div`
    .name{
        display: block;
        margin-bottom:10px;
        ${size.ft20};
        ${weight.normal};
    }
    .belong{
        display:block;
        margin-bottom:22px;
        ${size.ft14};
        color:${colors.grey6};
    }
    .info_list> li{
        margin-bottom:6px;
        ${size.ft14};
        color:${colors.grey6};
        .val{
            margin-left:12px;
            &.blue{
                color:${colors.blue};
            }
        }
        ul{
            margin:14px 0;
            li{
                margin-bottom:10px;
            }
        }
    }
    .btn_more{
        position:absolute;
        bottom:14px;
        right:20px;
        ${size.ft14};
        ${weight.normal};
        color:#4E789D;
        &:after{
            content:"";
            display:inline-block;
            width:13px;
            height:8px;
            margin-left:8px;
            ${icoCollect};
            background-position:-93px -43px;
        }
        &.open:after{
            background-position-y:-56px;    
        }
    }

`
export const ProgramBox=styled.div`
    margin:40px 0px 20px;
    padding:40px 20px;
    border:1px solid ${colors.greyE1};
    ul{
        padding:30px;
        background:rgb(242, 242, 242);
        li{
            margin-bottom:12px;
            .time{
                margin-right:20px;
                letter-spacing:-0.06em;
                color:${colors.blue};
                text-decoration:underline;
            }
        }
    }
`