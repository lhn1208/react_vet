
import { List } from "./aside.style";
import AsideImg from "../images/aside_img.jpg";

export default function AsideList({title, classify , presenter}){
 return (
    <>
         <h2 className="h2_title">{title}</h2>
         <List href="#none">
            <span className="img"><img src={AsideImg} alt="이미지 설명" /></span>
            <div className="cont">
                {classify && <p className="classify">{classify}</p>}
                <strong className="title">Clinical Implication of Glycemic Variability Glycemic Variabilit</strong>
                {presenter && <p className="txt_small">{presenter}</p>}
            </div>
         </List>
    </>
 );
}