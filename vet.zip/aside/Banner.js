import bannerImg from "../images/banner_right.jpg";
import bannerTopic from "../images/banner_topic.jpg";
import { BannerItem } from "./aside.style";

export default function Banner({type}){
 return <>
    <BannerItem href="#none">
        {type==="banner1" && ( <img src={bannerImg} alt=""></img>)}
        {type==="banner2" && ( <img src={bannerTopic} alt=""></img>)}
       
    </BannerItem>
 </>
 

}