import { IcoLabel } from "../class/class.style";
import { CheckBox } from "./common.style";

export default function InputClickEl({ onCheckboxChange, checkboxName, checkboxChecked, labelTxt }){
   
    return (
        <>
            <CheckBox>
                <label>
                    <input
                        type="checkbox"
                    >
                    </input>
                    <span></span>{checkboxName} 
                    {labelTxt &&
                        <IcoLabel className={labelTxt === "S" ? "pink" : "purple"}>
                            {labelTxt}
                        </IcoLabel>
                    }
                </label>
            </CheckBox>
        </>
    )
}