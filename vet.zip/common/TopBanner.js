import { AdBanner } from "../common/common.style";
import mainBannerImage from "../images/main_banner.jpg";

export default function TopBanner() {
    return(
        <AdBanner href="#none" className="contents_w">
            <img src={mainBannerImage} alt="베터빌 배너"/>
        </AdBanner>
    );
}