import { Search } from "./common.style";

export default function SearchBox(){
    return(
        <Search>
            <fieldset><legend>검색</legend><input type="search" id="" title="검색어를 입력하세요" placeholder="검색하세요." /><button className="btn_sch"><span className="offscreen">검색 아이콘</span></button></fieldset>
        </Search>

    )}