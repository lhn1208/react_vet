import { Link, useLocation } from "react-router-dom";
import { HeaderStyle, SkipNav, Inner, Member,Gnb, AllMenu, Submenu } from "./common.style";
import LogoImg from "../images/logo.png";
import SearchBox from "./SearchBox";
import { useState } from "react";

export default function Headr(){
    const location = useLocation();
    const [isActive, setIsActive] = useState(false);
    const handleButtonClick = () => {
        setIsActive(!isActive);
    };

    return(
        <HeaderStyle>
            <SkipNav>
                <a href="#content">본문 바로가기</a>
            </SkipNav>
            <Inner className="contents_w">
                <h1>   
                    <Link to="/"><img src={LogoImg} alt="베터빌 로고 이미지" /></Link>
                </h1>
                <menu>
                    <ul>
                        <li><a href="#none" className={location.pathname.startsWith('/class') ? 'on' : ''}>클래스룸</a>
                            <Submenu>
                                <li>
                                    <Link to="/class">임상강좌 VOD</Link>
                                    <Link to="/class/live">Live 세미나</Link>
                                    <Link to="/class/vod" >다시보기 VOD</Link>
                                </li>
                            </Submenu>
                        </li> 
                        <li><a href="#none" className={location.pathname.startsWith('/library') ? 'on' : ''}>라이브러리</a>
                            <Submenu>
                                <li>
                                    <Link to="/library">베터빌 뉴스</Link>
                                    <Link to="/library/reportsch">논문 검색</Link>
                                    
                                </li>
                            </Submenu>
                        </li> 
                        <li><a href="#none" className={location.pathname.startsWith('/community') ? 'on' : ''}>커뮤니티</a>
                            <Submenu>
                                <li>
                                    <Link to="/community">자유 게시판</Link>
                                    {/* <Link to="/community/tip">실전 진료 Tip</Link> */}
                                    <Link to="/community/dignos_case">진단케이스</Link>
                                    <Link to="/community/event" >이벤트</Link>
                                </li>
                            </Submenu>
                        </li> 
                    </ul>
                </menu>
                <div className="right">
                    <span className="identify">김베터 닥터</span>
                    <Member><span className="offscreen">멤버 아이콘</span><i>알람</i>
                        <Submenu member="true">
                            <li>
                                <a href="#none">마이페이지</a>
                                <a href="#none">고객센터</a>
                                <a href="#none">1:1문의하기</a>
                                <a href="#none">공지사항</a>
                                <a href="#none">로그아웃</a>
                            </li>
                        </Submenu>
                    </Member>
                    <SearchBox />
                    <Gnb onClick={handleButtonClick} className={isActive ? 'on' : ''}>
                        <span className="ico_menu">전체메뉴</span>
                    </Gnb>
                </div>
                
            </Inner>
            <AllMenu className={isActive ? 'on' : ''}>
                <div className="inner contents_w">
                    <div className="col">
                        <h2>클래스룸</h2>
                        <ul>
                            <li><a href="#none">임상강좌 VOD</a></li>
                            <li><a href="#none">라이브 세미나</a></li>
                            <li><a href="#none">다시보기 VOD</a></li>
                        </ul>
                    </div>
                    <div className="col">
                        <h2>라이브러리</h2>
                        <ul>
                            <li><a href="#none">베터빌 뉴스</a></li>
                            <li><a href="#none">의학논문검색</a></li>
                            <li><a href="#none">약물정보</a></li>
                        </ul>
                    </div>
                    <div className="col">
                        <h2>커뮤니티</h2>
                        <ul>
                            <li><a href="#none">자유게시판</a></li>
                            <li><a href="#none">진단케이스</a></li>
                            <li><a href="#none">이벤트</a></li>
                        </ul>
                    </div>
                </div>
            </AllMenu>
        </HeaderStyle>
    )
};