import LogoImg from "../images/logo.png";
import { Link } from "react-router-dom";
import { useState } from "react";
import { FamliySite, FooterLayout, FullContent } from "./common.style";
export default function Footer(){
    const [isOpen, setOpen] = useState(false);
    const handleToggle = () => {
        setOpen(!isOpen);
      };
    return (
        <FooterLayout>
            <FullContent className="footer">
                <div className="footer_inner">
                    <div className="vet_info">
                        <h1>   
                            <Link to="/"><img src={LogoImg} alt="베터빌 로고 이미지" /></Link>
                        </h1>
                        <div className="site_link">
                            <a href="#none">회사소개</a>
                            <a href="#none">고객센터</a>
                            <a href="#none">제휴문의</a>
                            <a href="#none">이용약관</a>
                            <a href="#none" className="point">개인정보처리방침</a>
                        </div>
                        <address>
                            <span>서울 강남구 봉은사로 114길 12 (삼성동)</span><span>대표전화 : 1522-0209</span><span>Fax : 02-563-8399</span>
                        </address>
                        <div className="copy">Copyright (c)Mcircle Corp. All rights reserved.</div>
                    </div>
                   <FamliySite>
                        <div className={isOpen ? "sites open" : "sites"}>
                            <a href="#none" target="_blank">하이닥</a>
                            <a href="#none" target="_blank">더샵</a>
                            <a href="#none" target="_blank">클릭메디</a>
                            <a href="#none" target="_blank">해피케어</a>
                            <a href="#none" target="_blank">시셀</a>
                            <a href="#none" target="_blank">닥터빌</a>
                        </div>
                        <button className="site_box" onClick={handleToggle}>Family Site</button>
                   </FamliySite>
                </div>
            </FullContent>
        </FooterLayout>
    )
}