import { ManageBox,BrnWrite } from "./commut.style";

export default function WriteManage(){
    return (
        <>
            <ManageBox>
                <div className="box_in">
                    닉네임을 등록해야 게시글을<br />작성할 수 있습니다.
                    <button className="btn">닉네임등록하기 &gt;</button>
                    {/* 매너:<span className="state">좋음 <i></i></span> */}
                </div>
                <button className="btn_box">내 글 관리</button>
            </ManageBox>
            <BrnWrite>
                <button>게시글 작성</button>
            </BrnWrite>
            
        </>

    )
}