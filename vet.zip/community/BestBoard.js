import { BestBoardList, BestBoardStyle } from "./commut.style";


export default function BestBoard(){
    return (
        <BestBoardStyle>
            <h2>인기 게시글</h2>
            <BestBoardList>
                <li>
                    <a href="#none">심방세동 원인과 질환의 이해 심방세동 원인과 질환의 이해 질환의 이해 심방세동 원인과 질환의 이해</a>
                    <span className="writer">김닥터</span>
                </li>
                <li>
                    <a href="#none">지식톡 최근답변 게시글 제목 지식톡 최근답변 게시글 제목 지식톡 지식톡 최근답변 게시글 제목 지식톡 최근답변 게시글 제목 지식톡</a>
                    <span className="writer">김닥터</span>
                </li>
                <li>
                    <a href="#none">지식톡 최근답변 게시글 제목 지식톡 최근답변 게시글 제목 지식톡 지식톡 최근답변 게시글 제목 지식톡 최근답변 게시글 제목 지식톡</a>
                    <span className="writer">김닥터</span>
                </li>
            </BestBoardList>
        </BestBoardStyle>
    )
}