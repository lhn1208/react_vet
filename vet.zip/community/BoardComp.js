import { Link } from "react-router-dom";
import { TableBoard } from "./commut.style";

export default function BoardComp() {
    return(
        <TableBoard>
            <table>
                <caption>자유게시판 리스트</caption>
                <colgroup>
                    <col width="80px" />
                    <col width="auto" />
                    <col width="185px;" />
                    <col width="100px" />
                    <col width="80px" />
                </colgroup>
                <thead>
                    <tr>
                        <th scope="col">번호</th>
                        <th scope="col" className="align_left">제목</th>
                        <th scope="col">작성자</th>
                        <th scope="col">작성일</th>
                        <th scope="col">추천</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>215</td>
                        <td className="title"><Link to="/community/boardview">이미지 사이트 추천해주세요</Link><span className="comm_cnt">[13]</span><i className="ico_new"></i></td>
                        <td>홍길동</td>
                        <td>2022-10-04</td>
                        <td>406</td>
                    </tr>
                    <tr>
                        <td>214</td>
                        <td className="title"><Link to="/community/boardview">세미나 수강 및 설문조사 후 포인트 적립이 되지 않아 문의 드립니다.</Link><span className="comm_cnt">[13]</span></td>
                        <td>김사무엘라</td>
                        <td>2023-10-04</td>
                        <td>406</td>
                    </tr>
                    <tr>
                        <td>213</td>
                        <td className="title"><Link to="/community/boardview">이미지 사이트 추천해주세요</Link></td>
                        <td>동물사랑협회</td>
                        <td>2022-10-04</td>
                        <td>406</td>
                    </tr>
                </tbody>
            </table>
        </TableBoard>
    )
}