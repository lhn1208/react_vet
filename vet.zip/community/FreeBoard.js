import Banner from "../aside/Banner";
import { Aside } from "../aside/aside.style";
import { ContainerWrap, } from "../common/common.style";
import SchInput from "../list/SchInput";
import SelectBox from "../list/SelectBox";
import { BtnMore, SchGroup } from "../list/list.style";
import BestBoard from "./BestBoard";
import BoardComp from "./BoardComp";
import WriteManage from "./WriteManage";
import { Visual,BordWrapStyle,BrnWrite } from "./commut.style";

export default function FreeBoard() {
    const select_list = [
        { label: '제목', value: 'title' },
        { label: '제목+내용', value: 'total' },
        { label: '내용', value: 'content' }
    ];
    return(
        <ContainerWrap id="content">
             <Visual freeboard>
                <div className="visual_inner">
                    <h2>자유게시판</h2>
                    <p>회원들과 자유롭게 이야기를 나누고, 함께 만들어가는 공간입니다.</p>
                </div>
            </Visual>
             <div className="container">
                <div className="inner_box">
                    <BordWrapStyle freeboard>
                        <SchGroup className="sch_area bt_gray">
                            <li className="sel">
                                <SelectBox selectList={select_list} />
                            </li>
                            <li className="sch">
                                <SchInput />
                            </li>
                        </SchGroup>
                        <BoardComp />
                        <BtnMore>더보기 1/5</BtnMore>
                        <BrnWrite>
                            <button>게시글 작성</button>
                        </BrnWrite>
                    </BordWrapStyle>
                </div>
                    <Aside>
                        <WriteManage />
                        <BestBoard />
                        <div>
                            <Banner type="banner1"/>
                        </div>
                    </Aside>
            </div>
        </ContainerWrap>
    )
}