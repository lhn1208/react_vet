import { CaseBoardList } from "./commut.style";
import docImg from '../images/dog_sample.jpg';

export default function CaseBoard() {
    return(
        <CaseBoardList>
            <ul>
                <li>
                    <a href="#none">
                        <figure><img src={docImg} alt="Dog Sample"/></figure>
                        <div className='board_cont'>
                        <strong className="title">반려동물 시술에 대한 교육자료 공유</strong>
                        <p>미국 항공우주국 홈페이지에 들어가면 누구나 허블 우주 망원경으로 관측해 촬영한 장엄한 우주 사진을 볼 수 있다.
                                                    장엄한 우주 사진을 볼 수 있다.</p>
                        <div className="info">
                            <span>베터빌 병원</span><span>2020-08-30</span><span>도움됐어요<span className='cnt'>5</span></span>
                        </div>
                    </div>  
                    </a>
                </li>
            </ul>
        </CaseBoardList>
    )
}