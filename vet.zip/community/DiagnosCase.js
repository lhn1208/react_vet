import AsideList from "../aside/AsideList";
import Banner from "../aside/Banner";
import { Aside } from "../aside/aside.style";
import { ContainerWrap } from "../common/common.style";
import SchInput from "../list/SchInput";
import { BtnMore, ListOptStyle, ListSort, SchGroup } from "../list/list.style";
import CaseBoard from "./CaseBoard";
import { BordWrapStyle, Visual } from "./commut.style";

export default function DignosCase() {
    return(
        <ContainerWrap id="content">
            <Visual case>
                <div className="visual_inner">
                    <h2>진단케이스</h2>
                    <p>임상에 도움이 되는 다양한 진단케이스와 처방 노하우, 처방 가이드를 제공합니다.</p>
                </div>
            </Visual>
             <div className="container">
                <div className="inner_box">
                    <BordWrapStyle>
                        <SchGroup className="sch_area">
                            <li>
                                <SchInput inputHolder="검색" />
                            </li>
                        </SchGroup>  
                        <ListOptStyle>
                            <strong>전체(10)</strong>
                            <div className="right">
                                <ListSort>
                                    <a href="#none" className="on">최신순</a>
                                    <a href="#none">조회순</a>
                                </ListSort>
                            </div>
                        </ListOptStyle>
                        <CaseBoard />
                        <CaseBoard />
                    </BordWrapStyle>
                    <BtnMore>더보기 1/5</BtnMore>
                </div>
                <Aside>
                    <div>
                        <AsideList
                            title="추천 VOD"
                            presenter="이정은 교수 (ㅇㅇㅇ병원 00내과)"
                        />
                    </div>
                    <div>
                        <Banner type="banner1"/>
                    </div>
                </Aside>
            </div>
        </ContainerWrap>
    )
}