import { ContainerWrap,FullContent } from "../common/common.style";
import { ListUl} from "../community/commut.style";
import EventImg from '../images/ev_sample2.jpg';

export default function Event() {
    return(
        <ContainerWrap id="content">
            <FullContent>
                <ListUl evt>
                    <li>
                        <a href="#none">
                            <figure><img src={EventImg} alt="" /></figure>
                            <figcaption>
                                <strong>출석체크 이벤트 삭감제로 프로젝트 실시합니다.</strong>
                                <span className="date">2016.06.01 ~ 2016.06.30</span>
                            </figcaption>
                        </a>
                    </li>
                    <li>
                        <a href="#none">
                            <figure><span className="cover">종료되었습니다.</span><img src={EventImg} alt="" /></figure>
                            <figcaption>
                                <strong>출석체크 이벤트 삭감제로 프로젝트 실시합니다.</strong>
                                <span className="date">2016.06.01 ~ 2016.06.30</span>
                            </figcaption>
                        </a>
                    </li>
                    <li>
                        <a href="#none">
                            <figure><img src={EventImg} alt="" /></figure>
                            <figcaption>
                                <strong>출석체크 이벤트 삭감제로 프로젝트 실시합니다.</strong>
                                <span className="date">2016.06.01 ~ 2016.06.30</span>
                            </figcaption>
                        </a>
                    </li>
                    <li>
                        <a href="#none">
                            <figure><span className="cover">종료되었습니다.</span><img src={EventImg} alt="" /></figure>
                            <figcaption>
                                <strong>출석체크 이벤트 삭감제로 프로젝트 실시합니다.</strong>
                                <span className="date">2016.06.01 ~ 2016.06.30</span>
                            </figcaption>
                        </a>
                    </li>
                    <li>
                        <a href="#none">
                            <figure><span className="cover">종료되었습니다.</span><img src={EventImg} alt="" /></figure>
                            <figcaption>
                                <strong>출석체크 이벤트 삭감제로 프로젝트 실시합니다.</strong>
                                <span className="date">2016.06.01 ~ 2016.06.30</span>
                            </figcaption>
                        </a>
                    </li>
                </ListUl>
            </FullContent>
        </ContainerWrap>
    )
}