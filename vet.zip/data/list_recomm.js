const list_recomm = [
    {
        link:"#",
        img:  require("../images/img_recomm.jpg"),
        classify: "웹컨퍼런스",
        alt: "추천콘텐츠 이미지",
        title:"새로운 심부전의 정의와 분류, 만성심부전과 급성심부전",
        desc:"기본 스캔부터 환자 증례까지, 간, 담낭담도, 췌장비장, 충수,  담낭담도, 췌장비장, 충수, 신장, 방관, 전립선 정확한 진단과 검진을 위한 아카데미",
        date: "2022.01.26 13:00~14:00"
    },
    {
        link:"#",
        img:  require("../images/img_recomm.jpg"),
        classify: "웹컨퍼런스",
        alt: "추천콘텐츠 이미지",
        title:"새로운 심부전의 정의와 분류, 만성심부전과 급성심부전",
        desc:"기본 스캔부터 환자 증례까지, 간, 담낭담도, 췌장비장, 충수,  담낭담도, 췌장비장, 충수, 신장, 방관, 전립선 정확한 진단과 검진을 위한 아카데미",
        date: "2022.01.26 13:00~14:00"
    },
]
export default list_recomm;