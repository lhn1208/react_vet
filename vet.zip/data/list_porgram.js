const list_program = [
    {
        link:"#",
        date:"7/20월요일",
        time:"09:00~12:00",
        classfiy:"세미나",
        cate: "호흡기질환",
        title:"[대한내분비학회] 맞춤 치료를 위한 인슐린 치료 전략",
        presenter:"최원석교수(세종병원 심장내과)",
        state:"비공개,대기중,라이브",
        apply:"Y",
        people:"648",
        total:"1000"
    },
    {
        link:"#",
        date:"7/20월요일",
        time:"13:00~18:00",
        classfiy:"세미나",
        cate: "호흡기질환",
        title:"[대한내분비학회] 맞춤 치료를 위한 인슐린 치료 전략",
        presenter:"최원석교수(세종병원 심장내과)",
        state:"라이브,",
        apply:"N",
        people:"648",
        total:"1000"
    },
    {
        link:"#",
        date:"7/21화요일",
        time:"09:00~12:00",
        classfiy:"세미나",
        cate: "호흡기질환",
        title:"[대한내분비학회] 맞춤 치료를 위한 인슐린 치료 전략",
        presenter:"최원석교수(세종병원 심장내과)",
        state:"비공개,대기중,",
        apply:"Y",
        people:"648",
        total:"1000"
    },
    {
        link:"#",
        date:"7/21화요일",
        time:"13:00~15:00",
        classfiy:"세미나",
        cate: "호흡기질환",
        title:"[대한내분비학회] 맞춤 치료를 위한 인슐린 치료 전략",
        presenter:"최원석교수(세종병원 심장내과)",
        state:"비공개, 대기중,",
        apply:"Y",
        people:"648",
        total:"1000"
    },
    {
        link:"#",
        date:"7/21화요일",
        time:"15:00~17:00",
        classfiy:"세미나",
        cate: "호흡기질환",
        title:"[대한내분비학회] 맞춤 치료를 위한 인슐린 치료 전략",
        presenter:"최원석교수(세종병원 심장내과)",
        state:"비공개, 대기중,",
        apply:"Y",
        people:"648",
        total:"1000"
    },
]
export default list_program;