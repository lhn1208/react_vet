const list_live = [
    {
        link:"#",
        img:  require("../images/thum_live_w277.jpg"),
        cate: "호흡기질환",
        alt: "live세미나 이미지",
        title:"2023 석천나눔재간 헬스케어 연구지원 및 연구실정발표 연구지원 및 연구실정발표 연구실정발표",
        date: "2022.01.26 13:00~14:00",
    },
    {
        link:"#",
        img:  require("../images/thum_live_w277.jpg"),
        cate: "호흡기질환",
        alt: "live세미나 이미지",
        title:"2023 석천나눔재간 헬스케어 연구지원 및 연구실정발표 연구지원 및 연구실정발표 연구실정발표",
        date: "2022.01.26 13:00~14:00",
    },
]
export default list_live;