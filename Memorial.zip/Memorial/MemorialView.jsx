import { ContWidth } from "../common/common.style"
import { ViewTopArea } from "./ViewTopArea"
import { ViewCont, ViewTop, ViewWrap } from "./memorial.style"
import mainImg from '../images/sample/img_memorial1.jpg'
import { PersonInfo } from "./PersonInfo"

export const MemorialView = () => {
  return (
    <ViewWrap>
      <ViewTop>
        <ContWidth>
           <ViewTopArea type="memorial" memorialImg={mainImg}/>
        </ContWidth>
      </ViewTop>
      <ViewCont>
        <PersonInfo 
          name="김경옥"
          date="1934-03-30 ~ 2022-08-20"
          btnText="추모관 전송"
        />
      </ViewCont>
    </ViewWrap>
  )
}